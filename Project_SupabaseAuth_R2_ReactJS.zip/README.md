# Project_SupabaseAuth_R2_ReactJS
Supabase - Login Authentication Prototype
