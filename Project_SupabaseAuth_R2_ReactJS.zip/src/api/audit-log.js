import axiosInstance from "../services/axios.service";

const BASE_URL = import.meta.env.VITE_API_BASE_URL;

export async function getUserActivity(page = 1, pageSize = 10, id) {
  const response = await axiosInstance.get(`${BASE_URL}/user-activity/${id}?page=${page}&pageSize=${pageSize}`);
  return response.data;
}