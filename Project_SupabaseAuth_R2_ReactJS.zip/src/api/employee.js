import axiosInstance from "../services/axios.service";

const BASE_URL = import.meta.env.VITE_API_BASE_URL;

export async function addEmployee(userPayload) {
  const response = await axiosInstance.post(`${BASE_URL}/employee`, userPayload);
  return response.data;
}

export async function getUsers(page = 1, pageSize = 10) {
  const response = await axiosInstance.get(`${BASE_URL}/employee?page=${page}&pageSize=${pageSize}`);
  return response.data;
}