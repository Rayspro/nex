import axiosInstance from "../services/axios.service";

const BASE_URL = import.meta.env.VITE_API_BASE_URL;

export async function signup(userPayload) {
  const response = await axiosInstance.post(`${BASE_URL}/signup`, userPayload);
  return response.data;
}

export async function login(userPayload) {
  const response = await axiosInstance.post(`${BASE_URL}/login`, userPayload);
  return response.data;
}

export async function logout() {
  const response = await axiosInstance.get(`${BASE_URL}/logout`);
  return response.data;
}

