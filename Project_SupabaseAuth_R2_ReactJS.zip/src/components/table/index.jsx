import { DataTable } from 'primereact/datatable';
import { Paginator } from 'primereact/paginator';

export default function Table({ children, data, first, rows, count, onPageChange, ...props }) {

  return <div>
    <DataTable rows={10} value={data || []} tableStyle={{ minWidth: '50rem' }} {...props}>
      {children}
    </DataTable>
    <Paginator
      first={first}
      rows={rows}
      totalRecords={count}
      onPageChange={onPageChange}
    />
  </div>;
}