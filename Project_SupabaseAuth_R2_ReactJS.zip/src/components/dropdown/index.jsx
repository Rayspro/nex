import { Dropdown } from 'primereact/dropdown';
export default function DropdownSelect({ label, name, options, value, className = "", placeholder = "", onChange, register, error }) {
  return (
    <div className={`input-group ${className}`}>
      {label && <label htmlFor={name}>{label}</label>}
      <Dropdown id={name} value={value} options={options} placeholder={placeholder} className='w-full input-text focus-visible placeholder' onChange={onChange} />
      {error && <p className='error'>{error.message}</p>}
    </div>
  )
}