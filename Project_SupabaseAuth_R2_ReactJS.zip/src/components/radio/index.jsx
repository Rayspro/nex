import { RadioButton } from 'primereact/radiobutton';
import React from 'react';
import { useState } from 'react';


const Radio = ({ label, radioList = [], checkedItem = "", name, onCheck, register, className = '', error }) => {

  return (
    <div className={`input-group ${className}`}>
      <label htmlFor={name}>{label}</label>
      <div className="flex justify-content-center">
        <div className="flex flex-wrap gap-3">
          {radioList.map(({ label, value }) => (
            <div className="flex align-items-center" style={{ margin: '0.5rem 0.5rem 0rem 0rem' }}>
              <RadioButton inputId={value} name={value} value={value} checked={checkedItem === value} onChange={onCheck} />
              <label style={{ marginLeft: '0.5rem' }} htmlFor={value} className="ml-2">{label}</label>
            </div>
          ))}
        </div>
      </div>
      {error && <p className='error'>{error.message}</p>}
    </div>
  );
};

export default Radio;