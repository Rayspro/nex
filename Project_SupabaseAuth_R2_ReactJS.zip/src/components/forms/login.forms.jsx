import React from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button, Input } from '../';
import { Link } from 'react-router-dom';
import google from "../../assets/images/google.svg";
import facebook from "../../assets/images/facebook.svg";

const loginSchema = z.object({
  email: z
    .string()
    .nonempty({ message: 'Email is required' })
    .email({ message: 'Invalid email address' }),
  password: z
    .string()
    .nonempty({ message: 'Password is required' })
    .min(6, { message: 'Password must be at least 6 characters' }),
});

const Login = ({ onLogin, isLoading }) => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(loginSchema),
  });

  const handleLogin = (provider) => {
    window.location.href = `http://localhost:4000/api/v1/auth/${provider}`;
  };


  return (
    <div className="card w-30rem">
      <h2>Login</h2>
      <form onSubmit={handleSubmit(onLogin)}>
        <Input
          label="Email"
          name="email"
          type="email"
          register={register}
          error={errors.email}
        />

        <Input
          label="Password"
          name="password"
          type="password"
          register={register}
          error={errors.password}
        />

        <Button loading={isLoading} className='w-full' type="submit">Login</Button>
      </form>

      <div className='form-option-container flex justify-center flex-col item-center'>
        <div>OR</div>
        <div className='social-group'>
          <img className='cursor-pointer' onClick={() => handleLogin('google')} src={google} />
          <span />
          <img className='cursor-pointer' style={{ marginLeft: "20px" }} onClick={() => handleLogin('facebook')} src={facebook} />
        </div>
        <span>Don't have an account ? <Link className="text-primary" to="/register"><span className="text-accent ml-1">Sign Up</span></Link></span>
      </div>
    </div>
  );
};

export default Login;