import React from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button, Input } from '../';
import Radio from '../radio';
import Dropdown from '../dropdown';
import DynamicInput from './dynamicInput';

const employeeSchema = z.object({
  fName: z
    .string()
    .nonempty({ message: 'First Name is required' }),
  lName: z
    .string()
    .nonempty({ message: 'Last Name is required' }),
  email: z
    .string()
    .nonempty({ message: 'Email is required' })
    .email({ message: 'Invalid email address' }),
  password: z
    .string()
    .nonempty({ message: 'Password is required' })
    .min(6, { message: 'Password must be at least 6 characters' }),
  checkIpOption: z.string().nonempty({ message: 'Email is required' }),
  restrictionType: z.string().optional(),
  ipAddresses: z
    .array(
      z.object({
        ip: z
          .string()
          .regex(
            /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/,
            "Invalid IP address"
          ),
      })
    )
    .optional(),
  confirmPassword: z
    .string()
    .nonempty({ message: 'Confirm Password is required' })
    .min(6, { message: 'Password must be at least 6 characters' }),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ['confirmPassword'],
}).refine((data) => {
  if (data.checkIpOption === "yes") {
    return data.restrictionType;
  }
  return true;
}, {
  message: 'Restriction Type is required',
  path: ['restrictionType'],
}).refine((data) => {
  if (data.restrictionType) {
    return data.ipAddresses && data.ipAddresses.length > 0;
  }
  return true;
}, {
  message: 'IP Address is required',
  path: ['ipAddresses'],
});

const AddEmployee = ({ onSubmit, isLoading }) => {
  const {
    register,
    handleSubmit,
    control,
    setValue,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(employeeSchema),
    defaultValues: {
      checkIpOption: 'no',
      ipAddresses: [],
    }
  });

  const [checkIpOption, setCheckIpOption] = React.useState('no');
  const [checkIpOptionType, setCheckIpOptionType] = React.useState(null);

  const isOptions = [
    { label: 'Yes', value: 'yes' },
    { label: 'No', value: 'no' },
  ];

  const typeOfRestriction = [
    { label: 'Custom restriction', value: 'custom-ip' },
    { label: 'Company level restriction', value: 'company-ip' },
  ];

  function onCheck(e) {
    if (e.value === 'no') {
      setCheckIpOptionType(null);
      setValue("restrictionType", "");
      setValue("ipAddresses", []);
    }
    setCheckIpOption(e.value);
    setValue("checkIpOption", e.value);
  }

  function onChangeOfRestrictionType(e) {
    setCheckIpOptionType(e.value);
    setValue("restrictionType", e.value);
    setValue("ipAddresses", [{ ip: "" }]);
  }

  return (
    <div className="employee">
      <form onSubmit={handleSubmit(onSubmit)}>
        <div className='form-group'>
          <Input
            className='input-container'
            label="First Name"
            placeholder="Enter First Name"
            name="fName"
            type="text"
            register={register}
            error={errors.fName}
          />
          <Input
            className='input-container'
            label="Last Name"
            name="lName"
            placeholder="Enter Last Name"
            type="text"
            register={register}
            error={errors.lName}
          />
        </div>
        {console.log(errors)}
        <Input
          label="Email"
          name="email"
          type="email"
          placeholder="Enter Email"
          register={register}
          error={errors.email}
        />
        <Radio label="IP Restrictions" register={register} radioList={isOptions} onCheck={onCheck} checkedItem={checkIpOption} />

        {checkIpOption === 'yes' && <Dropdown name="restrictionType" options={typeOfRestriction} placeholder='Select Resctriction Type' onChange={onChangeOfRestrictionType} value={checkIpOptionType} register={register} error={errors.restrictionType} />}

        {checkIpOptionType && checkIpOption === 'yes' && <DynamicInput
          name="ipAddresses"
          // lable="IP Addresses"
          control={control}
          error={errors}
        />}

        <Input
          label="Password"
          name="password"
          type="password"
          placeholder="Enter Password"
          register={register}
          error={errors.password}
        />

        <Input
          label="Confirm Password"
          name="confirmPassword"
          placeholder="Enter Confirm Password"
          type="password"
          register={register}
          error={errors.confirmPassword}
        />

        <Button loading={isLoading} className='w-full' type="submit">Add Employee</Button>
      </form >
    </div >
  );
};

export default AddEmployee;