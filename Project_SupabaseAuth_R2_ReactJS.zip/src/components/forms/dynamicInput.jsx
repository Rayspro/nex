import { InputText } from "primereact/inputtext";
import { Controller, useFieldArray } from "react-hook-form";
import Button from "../button";
import { SquareMinus, SquarePlus } from 'lucide-react';

export default function DynamicInput({ name, lable, className = '', error, control }) {

  const { fields, append, remove } = useFieldArray({
    control,
    name: "ipAddresses",
  });

  return <div className={`input-group ${className}`}>
    {lable && <label htmlFor={name}>{lable}</label>}
    {fields.map((field, index) => (
      <div key={field.id} className="p-field p-grid">
        <div className="flex item-center">
          <Controller
            name={`ipAddresses.${index}.ip`}
            control={control}
            defaultValue={field.ip}
            render={({ field }) => (
              <InputText {...field} placeholder="Enter IP address" />
            )}
          />

          <SquareMinus
            className="cursor-pointer"
            onClick={() => remove(index)}
            style={{ marginLeft: '10px' }}
          />
          <SquarePlus onClick={() => append({ ip: "" })} className="cursor-pointer" style={{ marginLeft: '10px' }} />
        </div>
        {error?.ipAddresses && error?.ipAddresses[index]?.ip && (
          <small className="p-error">
            {error?.ipAddresses[index]?.ip?.message}
          </small>
        )}
      </div>
    ))}
  </div>
}