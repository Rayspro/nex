// src/pages/Register.jsx
import React from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button, Input } from '../'; // Import the Input component
import { Link } from 'react-router-dom';

// Zod schema for validation
const registerSchema = z.object({
  name: z
    .string()
    .nonempty({ message: 'Name is required' }),
  email: z
    .string()
    .nonempty({ message: 'Email is required' })
    .email({ message: 'Invalid email address' }),
  password: z
    .string()
    .nonempty({ message: 'Password is required' })
    .min(6, { message: 'Password must be at least 6 characters' }),
  confirmPassword: z
    .string()
    .nonempty({ message: 'Confirm Password is required' })
    .min(6, { message: 'Password must be at least 6 characters' }),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ['confirmPassword'],
});

const Register = ({ onRegister, isLoading }) => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(registerSchema),
  });

  return (
    <div className="card w-30rem">
      <h2>Register</h2>
      <form onSubmit={handleSubmit(onRegister)}>
        <Input
          label="Full Name"
          name="name"
          register={register}
          error={errors.name}
        />

        <Input
          label="Email"
          name="email"
          type="email"
          register={register}
          error={errors.email}
        />

        <Input
          label="Password"
          name="password"
          type="password"
          register={register}
          error={errors.password}
        />

        <Input
          label="Confirm Password"
          name="confirmPassword"
          type="password"
          register={register}
          error={errors.confirmPassword}
        />

        <Button loading={isLoading} className='w-full' type="submit">Register</Button>
      </form>
      <div className='form-option-container flex justify-center flex-col item-center'>
        <div>OR</div>
        <span>Already have an account ? <Link className="text-primary" to="/"><span className="text-accent ml-1">Login</span></Link></span>
      </div>
    </div>
  );
};

export default Register;