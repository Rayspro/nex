import { Link } from "react-router-dom";
import * as icons from 'lucide-react';

export default function AdminSidebar({ modules = [] }) {

  return <div className="sidebar-root">
    <div className="sidebar-logo">Logo</div>
    {modules.map(module => {
      const Icon = icons[module?.icon || 'Monitor'];
      return <Link to={module.path}>
        <div className="sidebar-item">
          <table className="w-full">
            <tbody>
              <tr>
                <td className="w-20 flex justify-center text-xs">
                  {<Icon />}
                </td>
                <td className="w-80">
                  <span>{module.name}</span>
                </td>
                <td>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </Link>
    })}
  </div>;
}