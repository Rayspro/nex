import React from 'react';

const Input = ({ label, type = 'text', name, register, className = '', error, placeholder }) => {
  return (
    <div className={`input-group ${className}`}>
      {label && <label htmlFor={name}>{label}</label>}
      <input
        id={name}
        placeholder={placeholder}
        type={type}
        className='input-text focus-visible placeholder'
        {...register(name)}
      />
      {error && <p className='error'>{error.message}</p>}
    </div>
  );
};

export default Input;