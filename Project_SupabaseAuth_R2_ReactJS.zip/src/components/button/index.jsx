import React from 'react';

const Button = ({ loading, children, ...props }) => (
  <button className="button" {...props} disabled={loading || props.disabled}>
    {loading ? <div className="spinner"></div> : children}
  </button>
);

export default Button;