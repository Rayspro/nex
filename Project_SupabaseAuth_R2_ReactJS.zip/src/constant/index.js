import { Monitor } from 'lucide-react';

export const adminModules = [
  {
    name: "Dashobard",
    path: "/admin/dashboard",
    slug: "dashboard",
    icon: 'Monitor'
  },
];


export const userModules = [
  {
    name: "Dashobard",
    path: "/user/dashboard",
    slug: "dashboard",
    icon: 'Monitor'
  },
  {
    name: "Employee",
    path: "/user/employee",
    slug: "employee",
    icon: "UsersRound"
  }
];

export const RESTRICTION_TYPE = {
  'custom-ip': "Individual",
  'company-ip': "Organisation",
}