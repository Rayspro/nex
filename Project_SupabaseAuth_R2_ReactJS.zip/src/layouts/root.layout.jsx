export default function RootLayout({ children, className }) {
  return (
    <div className={`root custom-class ${className}`}>
      {children}
    </div>
  );
}