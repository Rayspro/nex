import { getTokenFromCookies } from "../services/cookies.service";

export default function PublicLayout({ children, className }) {

  const authToken = getTokenFromCookies();

  if (authToken) {
    return window.location.href = '/user/dashboard';
  }

  return (
    <div className={`public-root ${className}`}>
      {children}
    </div>
  );
}