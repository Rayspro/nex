import { Outlet } from "react-router-dom"
import Sidebar from "../components/sidebar/admin.sidebar";
import { userModules } from "../constant";
import { LogOut } from 'lucide-react';
import { deleteTokenFromCookies, getTokenFromCookies } from "../services/cookies.service";
import { useMutation } from '@tanstack/react-query';
import { logout } from "../api/auth.api";

export default function UserLayout({ children, className }) {

  const authToken = getTokenFromCookies();

  const { isLoading, mutate, isSuccess } = useMutation({
    mutationFn: () => logout(),

    onSuccess: (res) => {
      deleteTokenFromCookies();
      showToast('success', res?.message);
      window.location.href = '/';
    },
    onError: (err) => {
      showToast('error', err?.response?.data?.message || err?.message);
      console.log("Error occured", err);
    },
  });

  if (!authToken) {
    window.location.href = '/';
  }

  return (
    <div className={`admin-root`}>
      <Sidebar modules={userModules} />
      <div className="content-wrapper">
        <div className="admin-header">
          <div className="cursor-pointer">
            <LogOut onClick={() => mutate()} />
          </div>
        </div>
        <div className="admin-content"><Outlet /></div>
      </div>
    </div>
  );
}