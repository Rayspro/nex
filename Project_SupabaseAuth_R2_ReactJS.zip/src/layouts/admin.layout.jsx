import { Outlet } from "react-router-dom"
import AdminSidebar from "../components/sidebar/admin.sidebar";
import { adminModules } from "../constant";
import { LogOut } from 'lucide-react';

export default function AdminLayout({ children, className }) {
  return (
    <div className={`admin-root`}>
      <AdminSidebar modules={adminModules} />
      <div className="content-wrapper">
        <div className="admin-header">
          <div className="cursor-pointer">
            <LogOut />
          </div>
        </div>
        <div className="admin-content"><Outlet /></div>
      </div>
    </div>
  );
}