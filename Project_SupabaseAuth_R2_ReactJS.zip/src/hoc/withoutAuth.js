import React from 'react';
import { Route, Redirect } from 'react-router-dom';
import Cookies from 'js-cookie';

const withoutAuth = (WrappedComponent, redirectPath = '/user/dashboard') => {
  const AuthenticatedComponent = (props) => {
    const token = Cookies.get('token');
    if (!token) {
      return <WrappedComponent {...props} />
    } else {
      return <Redirect to={redirectPath} />;
    }
  };

  return AuthenticatedComponent;
};

export default withoutAuth;