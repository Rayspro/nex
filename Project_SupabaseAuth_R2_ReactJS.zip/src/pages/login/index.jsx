import React from 'react';
import { LoginForm } from '../../components'
import RootLayout from '../../layouts/root.layout';
import { useMutation } from '@tanstack/react-query';
import { login } from '../../api/auth.api';
import { saveTokenToCookies } from '../../services/cookies.service';
import { Toast } from 'primereact/toast';
import { useRef } from 'react';
import { useNavigate } from 'react-router-dom';

const Login = () => {

  const toast = useRef(null);
  const navigate = useNavigate();

  const { isLoading, mutate, isSuccess } = useMutation({
    mutationFn: (newUser) => login(newUser),

    onSuccess: (res) => {
      saveTokenToCookies(res?.data?.token);
      showToast('success', res?.message);
      navigate('/user/dashboard');

    },
    onError: (err) => {
      showToast('error', err?.response?.data?.message || err?.message);
      console.log("Error occured", err);
    },
  });

  function showToast(severity, summary) {
    try {
      toast.current.clear();
      toast.current.show({
        severity: severity,
        summary: summary,
        closable: false,
        life: 3000,
      })
    } catch (error) {
      console.log(error)
    }
  }


  const handleSubmit = async (payload) => {
    payload.deviceType = "web";
    await mutate(payload);
  };

  return (
    <RootLayout className="login">
      <Toast ref={toast} position="bottom-right" />
      <LoginForm isLoading={isLoading} onLogin={handleSubmit} />
    </RootLayout>
  );
};

export default Login;