export default function AdminDashboard() {
  return <div>Admin Dashboard</div>;
}