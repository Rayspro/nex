import React from 'react';
import RootLayout from '../../layouts/root.layout';
import { RegisterForm } from '../../components';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { signup } from '../../api/auth.api';
import { useNavigate } from 'react-router-dom';
import { Toast } from 'primereact/toast';
import { useRef } from 'react';

const Register = () => {

  const toast = useRef(null);
  const navigate = useNavigate();

  const { isLoading, mutate, isSuccess } = useMutation({
    mutationFn: (newUser) => signup(newUser),
    onSuccess: (res) => {
      showToast('success', res?.message);
      navigate('/');
    },
    onError: (err) => {
      showToast('error', err?.response?.data?.message || err?.message);
      console.log("Error occured", err)
    },
  });

  function showToast(severity, summary) {
    try {
      toast.current.clear();
      toast.current.show({
        severity: severity,
        summary: summary,
        closable: false,
        life: 3000,
      })
    } catch (error) {
      console.log(error)
    }
  }

  const handleSubmit = async (newUser) => {
    mutate(newUser);
  };

  return (
    <RootLayout className="register">
      <Toast ref={toast} position="bottom-right" />
      <RegisterForm isLoading={isLoading} onRegister={handleSubmit} />
    </RootLayout>
  );
};

export default Register;