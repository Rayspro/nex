import { useEffect } from "react";
import { saveTokenToCookies } from "../../services/cookies.service";

export default function SocialLoginCallback() {

  useEffect(() => {
    const queryParams = new URLSearchParams(window.location.search);
    const token = queryParams.get('token');

    if (token) {
      saveTokenToCookies(token);
      window.location.href = '/user/dashboard';
    }
  }, []);

  return <div className="callback-root">
    <span className="spinner"></span>
    <p className=""></p>
  </div>;
}