import { TabPanel } from 'primereact/tabview';
import Table from '../../components/table';
import { getUserActivity } from '../../api/audit-log';
import { useQuery } from '@tanstack/react-query';
import { useState } from 'react';
import { Column } from 'primereact/column';
import { serialNumberTemplate, showDateInBrowser } from '../../utils/formatter';

export default function AuditLog({ employee }) {

  const [first, setFirst] = useState(0);
  const [rows, setRows] = useState(10);
  const page = Math.floor(first / rows) + 1;

  const { data, isLoading: isDataLoading, refetch } = useQuery({
    queryKey: ['user-activity', page, rows],
    queryFn: () => getUserActivity(page, rows, employee?.id),
  });

  const onPageChange = (e) => {
    setFirst(e.first);
    setRows(e.rows);
  }

  return (
    <Table data={data?.data?.rows || []} count={data?.data?.count} onPageChange={onPageChange} first={first} rows={rows}>
      <Column body={(...props) => serialNumberTemplate(page, ...props)} header="S.No."></Column>
      <Column body={(rowData) => <p>{rowData.activityType?.toUpperCase()}</p>} header="Event"></Column>
      <Column body={(rowData) => <p>{showDateInBrowser(rowData?.createdAt)}</p>} header="When"></Column>
      <Column field="ip" header="From IP"></Column>
    </Table>
  )
}