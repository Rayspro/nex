import React, { useState } from 'react';
import { Column } from 'primereact/column';
import { Button } from '../../components';
import { Dialog } from 'primereact/dialog';
import AddEmployee from '../../components/forms/employee';
import { useMutation, useQuery } from '@tanstack/react-query';
import { addEmployee, getUsers } from '../../api/employee';
import { Toast } from 'primereact/toast';
import { useRef } from 'react';
import Table from '../../components/table';
import { RESTRICTION_TYPE } from '../../constant';
import { TabView, TabPanel } from 'primereact/tabview';
import EmployeeDetail from './detail';
import AuditLog from './audit-log';
import { showDateInBrowser } from '../../utils/formatter';

export default function Employee() {

  const [visible, setVisible] = useState(false);
  const [openEmployeeDialog, setOpenEmployeeDialog] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);
  const [updateIp, setUpdateIp] = useState(false);

  const toast = useRef(null);
  const [first, setFirst] = useState(0);
  const [rows, setRows] = useState(10);
  const [activeUser, setActiveUser] = useState({});
  const page = Math.floor(first / rows) + 1;

  const { data, isLoading: isDataLoading, refetch } = useQuery({
    queryKey: ['employees', page, rows],
    queryFn: () => getUsers(page, rows),
  });

  const { isLoading, mutate, isSuccess } = useMutation({
    mutationFn: (newUser) => addEmployee(newUser),

    onSuccess: (res) => {
      showToast('success', res?.message);
      setVisible(false);
      refetch();
    },
    onError: (err) => {
      showToast('error', err?.response?.data?.message || err?.message);
      console.log("Error occured", err);
    },
  });

  function showToast(severity, summary) {
    try {
      toast.current.clear();
      toast.current.show({
        severity: severity,
        summary: summary,
        closable: false,
        life: 3000,
      })
    } catch (error) {
      console.log(error)
    }
  }

  const handleSubmit = async (payload) => {
    delete payload.checkIpOption;
    if (payload?.ipAddresses?.length === 0) {
      delete payload.ipAddresses;
    }
    await mutate(payload);
  };

  const onPageChange = (e) => {
    setFirst(e.first);
    setRows(e.rows);
  }

  function openEmployeeDialogHandler(e) {
    try {
      setActiveUser(e?.rowData);
      setOpenEmployeeDialog(true);
    } catch (error) {
      console.log(error)
    }
  }

  function openEmployeeDialogCloseHandler() {
    try {
      setOpenEmployeeDialog(false);
      setActiveUser({});
    } catch (error) {
      console.log(error)
    }
  }

  return <div className="car">
    <div className='w-full flex justify-end' style={{ marginBottom: '1rem' }}>
      <Button icon="pi pi-plus" onClick={() => setVisible(true)}>Add Employee</Button>
    </div>

    <Dialog draggable={false} header="Add Employee" visible={visible} onHide={() => { if (!visible) return; setVisible(false); }} style={{ width: '30vw' }} breakpoints={{ '960px': '75vw', '641px': '100vw' }}>
      <AddEmployee isLoading={isLoading} onSubmit={handleSubmit} />
    </Dialog>

    <Dialog
      draggable={false}
      visible={openEmployeeDialog}
      onHide={() => { if (!openEmployeeDialog) return; setOpenEmployeeDialog(false); }}
      content={({ hide }) => <TabView activeIndex={activeIndex} onTabChange={(e) => setActiveIndex(e.index)}>
        <TabPanel header="Employee Detail">
          <EmployeeDetail employee={activeUser} />
          <div className='w-full flex justify-end'>
            <Button style={{ marginRight: '1rem' }}>Edit</Button>
            <Button onClick={openEmployeeDialogCloseHandler}>Close</Button>
          </div>
        </TabPanel>

        <TabPanel header="Audit Log">
          <AuditLog employee={activeUser} />
          <div className='w-full flex justify-end'>
            <Button onClick={openEmployeeDialogCloseHandler}>Close</Button>
          </div>
        </TabPanel>
      </TabView>}
      style={{ minWidth: '30vw' }} breakpoints={{ '960px': '75vw', '641px': '100vw' }}>
    </Dialog>

    <Table cellSelection selectionMode="single" onCellSelect={openEmployeeDialogHandler} data={data?.data?.rows || []} count={data?.data?.count} onPageChange={onPageChange} first={first} rows={rows}>
      <Column body={e => <div className='link' >{e?.firstName} {e?.lastName}</div>} field="firstName" header="Name"></Column>
      <Column field="email" header="Email"></Column>
      <Column field="allowedIp" body={e => (e?.UserIps || []).map(ip => <div>{ip.allowedIp}</div>) || "N/A"} header="Allowed IP"></Column>
      <Column body={e => (e?.UserIps || []).map(e => <div>{RESTRICTION_TYPE[e?.restrictionType] || "Everywhere"}</div>)} header="Restriction Type"></Column>
      <Column body={e => showDateInBrowser(e?.createdAt)} header="Sign up"></Column>
    </Table>
    <Toast ref={toast} position="bottom-right" />
  </div>;
} 