import user from "../../assets/images/user.png";
import { showDateInBrowser } from '../../utils/formatter';
import { SquarePlus } from 'lucide-react';

export default function EmployeeDetail({ employee }) {
  return (
    <div className="profile-container">
      <div>
        <div className="profile-image">
          <img src={user} alt="Profile" />
        </div>
        <h2 className="name">{employee?.firstName} {employee?.lastName || ""}</h2>
      </div>
      <table className="w-full">
        <tr>
          <td>
            <div>
              <label className="styled-label">Email</label>
              <p className="styled-content">{employee?.email}</p>
            </div>
          </td>
          <td>
            <div>
              <label className="styled-label">Sign Up Date</label>
              <p className="styled-content">{showDateInBrowser(employee?.createdAt)}</p>
            </div>
          </td>
        </tr>
        <tr>
          <td>
            <div className="flex">
              <label className="styled-label">Allowed IP</label>
              <SquarePlus size={20} style={{ marginLeft: '0.5rem' }} className="cursor-pointer" />
            </div>
            <p className="styled-content">{(employee?.UserIps || []).map(ip => <span>{ip?.allowedIp}</span>)}</p>
          </td>
          <td>
            <div>
              <label className="styled-label">Assigned By</label>
              <p className="styled-content">{(employee?.UserIps || []).map(ip => <span>{ip?.User?.firstName}</span>)}</p>
            </div>
          </td>
        </tr>
      </table>
    </div>
  )
}