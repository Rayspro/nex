import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Login from './pages/login';
import Register from './pages/register';
import UserLayout from './layouts/user.layout';
import Dashboard from './pages/dashboard';
import SocialLoginCallback from './pages/social-login-callback';
import PublicLayout from './layouts/public.layout';
import Employee from './pages/employee';

function App() {

  return (
    <Router>
      <Routes>
        <Route path="/" element={<PublicLayout>
          <Login />
        </PublicLayout>} />
        <Route path="/register" element={<PublicLayout>
          <Register />
        </PublicLayout>} />
        <Route path="/callback" element={<SocialLoginCallback />} />

        <Route path="user" element={<UserLayout />} >
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="employee" element={<Employee />} />
        </Route>

      </Routes>
    </Router>
  );
}

export default App;