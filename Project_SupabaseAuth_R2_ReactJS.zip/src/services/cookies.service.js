import Cookies from 'js-cookie';

export const saveTokenToCookies = (token) => {
  // Save token in a cookie that expires in 7 days
  Cookies.set('authToken', token, { expires: 7, path: '/', secure: true, sameSite: 'Strict' });
};

export const getTokenFromCookies = () => {
  return Cookies.get('authToken');
};

export const deleteTokenFromCookies = () => {
  Cookies.remove('authToken', { path: '/' });
};