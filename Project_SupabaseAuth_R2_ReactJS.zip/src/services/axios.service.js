import axios from 'axios';
import { deleteTokenFromCookies, getTokenFromCookies } from './cookies.service';

// Create an Axios instance with default configurations
const axiosInstance = axios.create({
  baseURL: 'https://api.example.com', // Replace with your API base URL
  timeout: 10000, // Set a timeout for requests (in milliseconds)
  headers: {
    'Content-Type': 'application/json',
    // Add any other default headers here
  },
});

// Request interceptor
axiosInstance.interceptors.request.use(
  config => {
    // You can modify the request config here, e.g., add authentication tokens
    // const token = localStorage.getItem('token'); // Example: get token from localStorage
    // if (token) {
    //   config.headers['Authorization'] = `Bearer ${token}`;
    // }
    const authToken = getTokenFromCookies();

    if (authToken) {
      config.headers['authorization'] = `Bearer ${authToken}`;
    }
    console.log("rtere", authToken)
    return config;
  },
  error => {
    // Handle request error
    return Promise.reject(error);
  }
);

// Response interceptor
axiosInstance.interceptors.response.use(
  response => {
    // You can modify the response here if needed
    console.log(response)
    return response;
  },
  error => {
    // Handle response error
    // Example: Handle 401 Unauthorized errors globally
    if (error.response && error.response.status === 401) {
      deleteTokenFromCookies();
      window.location.href = '/';
    }
    return Promise.reject(error);
  }
);

export default axiosInstance;