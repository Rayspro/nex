import moment from "moment";

export const showDateInBrowser = (data) => {
  // return moment(data).format('DD/MM/YYYY hh:mm A');
  try {
    return moment(data)
      .tz(moment.tz.guess())
      .format('Do MMMM, YYYY, HH:mm A');
  } catch (error) {
    return moment(data).format('Do MMMM, YYYY, HH:mm A');
  }
};


export const serialNumberTemplate = (page, rowData, { rowIndex, ...props }) => {
  return (page - 1) * 10 + rowIndex + 1;
};