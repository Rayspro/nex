const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const { join, resolve } = require('path');
const utils = require('./utils/index.js');
const router = require('./v1/routes/index.js');
const ValidationError = require('./utils/ValidationError.js');
const services = require('./services/index.js');
const { loggerErrorMessage } = require('./logMessages/index.js');
const { logger } = require('./services/logger.service.js');
const { getErrorString } = require('./helper/common.js');
const { errStack } = require('./helper/error-stack.js');
require("./services/passport.service.js")

/**
 * Initialize the Express application
 * @returns {Promise<Express.Application>} Promise that resolves to the Express application instance
 */
function init() {
  return new Promise((resolvePromise, reject) => {
    try {
      // Create Express application
      const app = express();
      // Set views directory and view engine
      app.set('views', join(__dirname, 'ejs'));
      app.set('view engine', 'ejs');

      app.enable('trust proxy')

      app.use((req, res, next) => {
        // Get IP address from the request
        const ip = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
        console.log('IP: ', ip);
        next();
      });

      // Middleware
      app.use(express.json());
      app.use(express.urlencoded({ extended: true }));
      app.use('/assets', express.static(`${resolve()}/uploads`));
      app.use('/images', express.static(`${resolve()}/images`));
      app.use('/public', express.static(`${resolve()}/public`));
      app.use(cors());
      app.use(
        helmet({
          contentSecurityPolicy: false,
          referrerPolicy: false,
          originAgentCluster: false,
        })
      );

      // Logging middleware
      app.use((req, res, next) => {
        console.log('URL: ', req?.url);
        next();
      });

      // Set application port
      app.set('port', utils.getEnv('APP_PORT'));
      services.swagger(app);
      router(app);

      // Initialize routers

      // Error handling middleware
      app.use((error, req, res, next) => {
        // Log error
        logger('ERROR').info(`Error : ${JSON.stringify(error || {})}`);
        if (error) {
          loggerErrorMessage(null, { error });
        }

        // Determine HTTP status code
        let statusCode = error?.status
          ? utils.httpStatus('BAD_REQUEST')
          : utils.httpStatus('INTERNAL_SERVER_ERROR');

        // Handle specific error cases
        if (error?.status === utils.httpStatus('UNAUTHORIZED')) {
          statusCode = utils.httpStatus('UNAUTHORIZED');
        }
        const newError = error;
        if (
          error?.prototype &&
          error?.prototype.constructor.name &&
          Object.keys(errStack || {}).includes(`${error?.constructor()}`)
        ) {
          const errInstance = errStack[`${error.constructor()}`];
          newError.message = getErrorString(error);
          newError.status =
            errInstance?.responseCode ||
            utils.httpStatus('INTERNAL_SERVER_ERROR');
          statusCode =
            errInstance?.responseCode ||
            utils.httpStatus('INTERNAL_SERVER_ERROR');
        }
        // Send error response
        res.status(statusCode).json({
          success: false,
          data: null,
          error: newError,
          message:
            statusCode === utils.httpStatus('INTERNAL_SERVER_ERROR')
              ? getErrorString(error) ||
              utils.getMessage(req, false, 'INTERNAL_ERROR')
              : String(error?.message)
                ?.replace(/Error:/g, '')
                ?.trim(),
          mobileErrorMessage: utils.getMessage(
            req,
            false,
            'MOBILE_ERROR_MESSAGE'
          ),
        });
      });

      // Handle 404 Not Found error
      app.use((req, res) => {
        const error = new Error('Not Found');
        error.status = utils.httpStatus('NOT_FOUND');
        res.status(error.status).json({
          success: false,
          data: null,
          error,
          message: error.message,
        });
      });

      // Handle other routes
      app.all('*', (req, res) => {
        res.json('');
      });

      // Handle ValidationError
      app.use((err, req, res) => {
        if (err instanceof ValidationError) {
          res.status(err.statusCode).json(req.errors);
        }
      });

      // Resolve the promise with the Express app instance
      resolvePromise(app);
    } catch (err) {
      // Reject the promise with error if initialization fails
      reject(err);
    }
  });
}

module.exports = init;
