const utils = require('../utils/environment');
// Exporting application configuration object
module.exports = {
  app: {
    cacheTimeOutForDashbord: utils.getEnv('DASHBOARD_CACHE_TIMEOUT'),
    name: utils.getEnv('APP_NAME'),
    baseUrl: utils.getEnv('BASE_URL'),
    siteName: utils.getEnv('APP_NAME'),
    siteUrl: utils.getEnv('SITE_URL'),
    cronEnv: utils.getEnv('CRON_ENV'),
    dateFormat: 'YYYY-MM-DD',
    mediaStorage: utils.getEnv('MEDIA_STORAGE'), // local,
    adminUrl: utils.getEnv('ADMIN_URL'),
    reqDuration: utils.getEnv('MAX_REQ_DURATION'),
    environment: utils.getEnv('NODE_ENV'),
    swaggerHost: utils.getEnv('SWAGGER_HOST'),
    languages: ['en'],
    setBaseUrl(url) {
      this.baseUrl = url;
    },
    mailServer: utils.getEnv('MAIL_ENV'),
    maximumCostLimit: true,
    isServerBreakEmailSend: utils.getEnv('SERVER_BREAK_EMAIL') ?? false,
    mailSenderType: utils.getEnv('MAIL_SENDER_TYPE') ?? 'SMTP', // SES, SENDGRID, SMTP,
  },
  // Secret key for JWT
  jwtSecret: utils.getEnv('JWT_SECRET'),
  jwtExpireIn: utils.getEnv('JWT_EXPIRE_IN'),
};
