const utils = require('../utils/environment');
// Exporting SMTP configuration object
module.exports = {
  smtp: {
    pool: true,
    host: utils.getEnv('SMTP_HOST'),
    port: utils.getEnv('SMTP_PORT'),
    secure: false, // use TLS
    tls: { rejectUnauthorized: false },
    auth: {
      user: utils.getEnv('SMTP_USER'),
      pass: utils.getEnv('SMTP_PASSWORD'),
    },
  },
  // Default email address to send emails from
  fromEmail: utils.getEnv('MAIL_FROM_EMAIL'),
  fromName: utils.getEnv('MAIL_FROM_NAME'),
};
