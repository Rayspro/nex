const regex = require('./regex.js');

module.exports = {
  ...regex,
};
