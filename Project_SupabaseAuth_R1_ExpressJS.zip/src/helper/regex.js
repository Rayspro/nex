/**
 * Regular expressions for common validation patterns.
 */
module.exports = {
  strongPassword:
    /(?=[A-Za-z0-9@#$%^&+!=]+$)^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[@#$%^&+!=])(?=.{6,}).*$/,
  countryCode: /^(\+?\d{1,3}|\d{1,4})$/,
  phoneNumber: /^\d+$/,
  digit: /^\d+$/,
  alphanumeric: /^[a-zA-Z0-9]+$/,
  // eslint-disable-next-line security/detect-unsafe-regex
  message: /^[^\s]+(\s.*)?$/,
};
