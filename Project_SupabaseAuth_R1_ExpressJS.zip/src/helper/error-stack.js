const httpStatus = require('http-status');
/**
 * Stack of predefined error instances and their associated response codes.
 /** */
module.exports.errStack = {
  RangeError: {
    message: '',
    responseCode: httpStatus.BAD_REQUEST,
  },
};
