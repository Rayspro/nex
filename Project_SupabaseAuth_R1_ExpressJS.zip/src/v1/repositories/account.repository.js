const { Op, where } = require('sequelize');
const bcrypt = require('bcryptjs');
const models = require('../models/index.js');
const jwt = require('../../services/jwt.service.js');
const { accountErrorMessage } = require('../../logMessages/index.js');
const utility = require('sharp/lib/utility.js');

const { User, UserDevice, UserIp } = models;

module.exports.signup = async (req) => {
  const { body } = req;

  body.firstName = body?.fName?.trim();
  body.lastName = body?.lName?.trim();
  try {
    const hashPassword = await this.createHashPassword(body?.password);
    const user = await User.create({ ...body, password: hashPassword });
    return user;
  } catch (error) {
    accountErrorMessage('signup', { error, body });
    throw Error(error);
  }
};

module.exports.checkUserAccountLogin = async (req) => {
  try {
    const {
      body: { email, password, firebaseToken, deviceType },
    } = req;
    const where = {
      [Op.or]: [{ email }],
    };

    const user = await User.findOne({
      where,
    });
    if (user) {
      const isPasswordMatch = await this.compareUserPassword(
        password,
        user?.password
      );
      if (isPasswordMatch === true) {
        const tokenData = {
          id: user.id,
          firstName: user.firstName,
          lastName: user.lastName,
          email: user.email,
          phoneNumber: user.phoneNumber,
          restrictionType: user.restrictionType,
          allowedIp: user.allowedIp,
        };
        const token = await jwt.createToken(tokenData);
        const deviceData = {
          userId: tokenData?.id,
          deviceId: firebaseToken,
          deviceType,
          accessToken: token,
        };
        if (token) {
          await this.addUserDevice(deviceData);
        }
        return { ...tokenData, token };
      }
      return null;
    }
  } catch (error) {
    accountErrorMessage('webLogin', { error, data: req?.body });
    throw Error(error);
  }
};

/**
 * Get Device Detail by Token
 * @param {string} token - The access token
 * @returns {Promise<Object|null>} - The device details if found, otherwise null
 */
module.exports.getDeviceDetailByToken = async (token) => {
  try {
    return await UserDevice.findOne({
      where: {
        accessToken: token,
      },
    });
  } catch (error) {
    accountErrorMessage('deviceDetailByToken', { error, data: token });
    throw Error(error);
  }
};


module.exports.createHashPassword = async (password) => {
  try {
    const salt = await bcrypt.genSalt();
    return await bcrypt.hash(password, salt);
  } catch (error) {
    accountErrorMessage('createHashPassword', { error, password });
    throw Error(error);
  }
};


module.exports.addUserDevice = async (data, transaction) => {
  try {
    if (transaction) {
      return await UserDevice.create(data, { transaction });
    }
    return await UserDevice.create(data);
  } catch (error) {
    accountErrorMessage('addUserDevice', { error, data });
    throw Error(error);
  }
};

/**
 * Function to Check Password
 * @param {string} password - The password to check
 * @param {string} hashPassword - The hashed password to compare with
 * @returns {Promise<boolean>} - True if passwords match, otherwise false
 */
module.exports.compareUserPassword = async (password, hashPassword) => {
  if (password && hashPassword) {
    const isPasswordMatch = await bcrypt.compare(password, hashPassword);
    return !!isPasswordMatch;
  }
  return false;
};

module.exports.logoutUser = async (id, userId) => {
  try {
    return await UserDevice.destroy({ where: { id } });
  } catch (error) {
    accountErrorMessage('logoutUser', { error, id });
    throw Error(error);
  }
};


module.exports.updateToken = async (user) => {
  try {
    const userId = user?.dataValues?.id;
    const payload = {};
    payload.accessToken = user?.token;
    payload.userId = userId;
    if (userId && payload?.accessToken) {
      await UserDevice.destroy({ where: { id: userId } });
      await UserDevice.create(payload);
    } else {
      throw new Error("Something went wrong");
    }
    return { ...user };
  } catch (error) {
    throw Error(error);
  }
}

module.exports.validateIP = async (user, source_ip) => {
  try {
    if (restrictionType === 'custom-ip') {
      const userIps = await UserIp.findAll({ where: { userId: user.id, restrictionType: 'custom-ip', allowedIp: source_ip } });
      if (userIps?.length > 0) {
        return user;
      }
      const error = new Error('You are not authorized to login from this IP Address');
      throw error;
    }
    return user;
  } catch (err) {
    throw Error(err);
  }
}