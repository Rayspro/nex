const models = require('../models/index.js');
const { createHashPassword } = require('./account.repository.js');

const { User, UserIp } = models;

module.exports.createUser = async (firstName, lastName, email, imposedBy, password, ipAddresses = [], restrictionType = "public") => {
  try {
    const hashedPaswword = await createHashPassword(password);
    const user = await User.create({ firstName, lastName, email, password: hashedPaswword });

    const userIpsPromise = await ipAddresses.map(async (ipAddress) => {
      await UserIp.create({ userId: user.id, imposedBy: imposedBy, allowedIp: ipAddress?.ip, restrictionType });
    })

    await Promise.all(userIpsPromise);

    return user;
  } catch (err) {
    console.log(err);
    throw Error(error);
  }
}

module.exports.updateUser = async (id, firstName, lastName, imposedBy, password, ipAddresses = [], restrictionType = "public") => {
  try {
    const payload = { firstName, lastName };
    if (password) {
      const hashedPaswword = await createHashPassword(password);
      payload.password = hashedPaswword;
    }
    const user = await User.update({ ...payload }, { where: { id: id } });

    await UserIp.destroy({ where: { userId: id } });


    const userIpsPromise = await ipAddresses.map(async (ipAddress) => {
      await UserIp.create({ userId: id, imposedBy: imposedBy, allowedIp: ipAddress?.ip, restrictionType });
    })

    await Promise.all(userIpsPromise);

    return user;
  } catch (err) {
    console.log(err);
    throw Error(error);
  }
}

module.exports.getUsers = async (page = 1, pageSize = 10) => {
  try {
    const offset = (page - 1) * pageSize;
    const users = await models.User.findAndCountAll({
      limit: pageSize,
      offset: offset,
      order: [['createdAt', 'desc']],
      include: [{
        model: UserIp,
        include: [{
          model: models.User,

        }]
      }]
    });
    return users;
  } catch (err) {
    throw Error(err);
  }
}