/* eslint-disable camelcase */
const { Op } = require('sequelize');
const repositories = require('../repositories/index.js');
const utility = require('../../utils/index.js');
const models = require('../models/index.js');

const { accountRepository } = repositories;
const { User } = models;


/**
 *  Check reset url token
 * @param {object} req - The request object containing the token in the body or params
 * @param {object} res - The response object
 * @param {Function} next - The next middleware function
 */
module.exports.checkValidToken = async (req, res, next) => {
  try {
    const {
      body: { token },
      params,
    } = req;
    const data = await User.scope('notDeletedUser').findOne({
      where: { resetPasswordToken: params?.token || token, status: 'active' },
    });

    if (data) {
      req.data = data;
      req.user = data;
      next();
    } else {
      const error = new Error(utility.getMessage(req, false, 'TOKEN_EXPIRED'));
      error.status = utility.httpStatus('NOT_FOUND');
      next(error);
    }
  } catch (err) {
    next(err);
  }
};

/**
 * Check email exists
 * @param {Object} req - The request object containing email, phoneNumber, and scope
 * @param {Object} res - The response object
 * @param {Function} next - The next middleware function
 */
module.exports.checkEmailExists = async (req, res, next) => {
  try {
    const {
      body: { email, scope },
      user,
      params: { id },
    } = req;
    const where = { [Op.or]: [{ email }] };
    if (id || user?.id) {
      where.id = { [Op.ne]: id ?? user?.id };
    }
    const data = await User.scope(scope ?? 'notDeletedUser').findOne({
      where,
    });
    if (data?.email.toLowerCase() === email.toLowerCase()) {
      const error = new Error(
        utility.getMessage(
          req,
          false,
          data?.status === 'deleted' ? 'DELETED_EMAIL_EXIST' : 'EMAIL_EXIST'
        )
      );
      error.status = utility.httpStatus('BAD_REQUEST');
      next(error);
    } else {
      next();
    }
  } catch (error) {
    next(error);
  }
};

/**
 * Check user exists by email
 * @param {Object} req - The request object containing email or mobile number
 * @param {Object} res - The response object
 * @param {Function} next - The next middleware function
 */
module.exports.findUserByEmail = async (req, res, next) => {
  try {
    const {
      body: { email, emailOrMobile },
    } = req;
    let where = {};
    if (!emailOrMobile) {
      const error = new Error('Email or mobile number is required.');
      error.status = utility.httpStatus('BAD_REQUEST');
      return next(error);
    }
    if (emailOrMobile) {
      where = {
        ...where,
        [Op.or]: [{ email: emailOrMobile }, { phoneNumber: emailOrMobile }],
      };
    }
    if (email) {
      where.email = email;
    }
    const user = await User.findOne({ where });
    if (user) {
      req.user = user;
      next();
    } else {
      const msg = emailOrMobile.match(/^\d+$/)
        ? 'FORGOT_MOBILE_NUMBER_NOT_FOUND'
        : 'EMAIL_NOT_FOUND';
      const error = new Error(utility.getMessage(req, false, msg));
      error.status = utility.httpStatus('BAD_REQUEST');
      next(error);
    }
  } catch (err) {
    next(err);
  }
};


