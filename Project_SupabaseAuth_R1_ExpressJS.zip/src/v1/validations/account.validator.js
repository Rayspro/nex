const Joi = require('joi');
const { schemaValueGet } = require('../../utils/common.js');
const { strongPassword, phoneNumber } = require('../../helper/regex.js');

// Common validation schema used across multiple schemas
const commonValidation = {
  emailOrMobile: Joi.alternatives()
    .try(
      Joi.string()
        .label('Phone number')
        .min(10)
        .max(10)
        .messages({
          'string.pattern.base': 'ONLY_NUMERIC_ALLOWED',
          'string.min': 'PHONE_NUMBER_MAX_LENGTH',
        })
        .regex(phoneNumber)
        .empty()
        .messages({
          'string.pattern.base': 'ONLY_NUMERIC_ALLOWED',
          'string.max': 'PHONE_NUMBER_MAX_LENGTH',
        }),
      Joi.string()
        .trim()
        .label('Email')
        .email({ minDomainSegments: 2, tlds: { allow: false } })
        .required()
    )
    .messages({
      'alternatives.match': 'EMAIL_MOBILE_NUMBER_ALLOWED',
    }),
  email: Joi.string()
    .label('Email')
    .email({ minDomainSegments: 2, tlds: { allow: false } })
    .min(6)
    .max(100)
    .required(),
  password: Joi.string().label('Password').trim(),
  name: Joi.string().label('Name').required(),
  fName: Joi.string().label('fName').required(),
  lName: Joi.string().label('lName').required(),
  profilePicture: Joi.string().allow('').optional(),
  phoneNumber: Joi.string()
    .label('Phone number')
    .min(10)
    .max(10)
    .messages({
      'string.pattern.base': 'ONLY_NUMERIC_ALLOWED',
      'string.min': 'PHONE_NUMBER_MAX_LENGTH',
    })
    .regex(phoneNumber)
    .empty()
    .messages({
      'string.pattern.base': 'ONLY_NUMERIC_ALLOWED',
      'string.max': 'PHONE_NUMBER_MAX_LENGTH',
    }),
  confirmPassword: Joi.string()
    .label('Password and confirm password do not match')
    .valid(Joi.ref('password')),
  newPassword: Joi.string()
    .trim()
    .min(6)
    .max(15)
    .label('Password')
    .regex(strongPassword)
    .messages({
      'string.pattern.base': 'PASSWORD_VALIDATION',
    })
    .required(),
  currentPassword: Joi.string()
    .trim()
    .min(6)
    .max(15)
    .label('Password')
    .regex(strongPassword)
    .messages({
      'string.pattern.base': 'PASSWORD_VALIDATION',
    }),
  deviceType: Joi.string()
    .label('Device Type')
    .valid('android', 'ios', 'web')
    .required(),

  firebaseToken: Joi.string()
    .label('Firebase Token')
    .optional()
    .empty()
    .allow(''),
  ipAddresses: Joi.array()
    .label('Allowed IP')
    .optional()
    .empty()
    .allow(''),
  restrictionType: Joi.string()
    .label('Restrction Type')
    .valid('custom-ip', 'company-ip', 'public')
    .optional()
    .empty()
    .allow(''),

};
const changePasswordValidation = {
  currentPassword: Joi.string()
    .trim()
    .min(6)
    .max(15)
    .label('Password')
    .regex(strongPassword)
    .messages({
      'string.pattern.base': 'PASSWORD_VALIDATION',
    })
    .required(),

  token: Joi.string().required(),

  newPassword: Joi.string()
    .trim()
    .min(6)
    .max(15)
    .label('Password')
    .regex(strongPassword)
    .messages({
      'string.pattern.base': 'PASSWORD_VALIDATION',
    })
    .required(),

  confirmPassword: Joi.string()
    .label('Password and confirm password do not match')
    .required()
    .valid(Joi.ref('newPassword')),
};

// Schema for user account signup
const userAccountSignupSchema = {
  body: Joi.object().keys(
    schemaValueGet(
      [
        'fName',
        'lName',
        'password',
        'profilePicture',
        'confirmPassword',
        'email',
        'ipAddresses',
        'restrictionType',
      ],
      commonValidation
    )
  ),
};

const userUpdateSchema = {
  body: Joi.object().keys(
    schemaValueGet(
      [
        'fName',
        'lName',
        'password',
        'confirmPassword',
        'ipAddresses',
        'restrictionType',
      ],
      commonValidation
    )
  ),
};

// Schema for admin user account login
const userAdminAccountLoginSchema = {
  body: Joi.object().keys(
    schemaValueGet(['email', 'password'], commonValidation)
  ),
};




// Schema for user account login
const userAccountLoginSchema = {
  body: Joi.object(
    schemaValueGet(
      ['email', 'password', 'deviceType'],
      commonValidation
    )
  ),
};


module.exports = {
  userAccountSignupSchema,
  userAdminAccountLoginSchema,
  userAccountLoginSchema,
  userUpdateSchema
};
