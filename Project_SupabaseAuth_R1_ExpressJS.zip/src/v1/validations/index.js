const accountValidator = require('./account.validator.js');

module.exports = {
  accountValidator,
};
