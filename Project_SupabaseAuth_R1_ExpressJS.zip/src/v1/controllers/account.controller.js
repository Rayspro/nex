const repositories = require('../repositories/index.js');
const utility = require('../../utils/index.js');

const { accountRepository, userActivityRepository } = repositories;

module.exports.signup = async (req, res, next) => {
  try {
    const result = await accountRepository.signup(req);
    if (result) {
      await userActivityRepository.createActivity('signup', 'authorized', req?.ip, result?.id);
      res.status(utility.httpStatus('OK')).json({
        success: true,
        data: {},
        message: utility.getMessage(req, false, 'SIGNUP'),
      });
    } else {
      res.status(utility.httpStatus('BAD_REQUEST')).json({
        success: false,
        data: null,
      });
    }
  } catch (error) {
    next(error);
  }
};

module.exports.checkUserAccountLogin = async (req, res, next) => {
  try {
    const user = await accountRepository.checkUserAccountLogin(req);
    if (user) {
      const result = await accountRepository.validateIP(user, req?.ip);
      if (user && result) {
        await userActivityRepository.createActivity('login', 'authorized', req?.ip, user?.id);
        res.status(utility.httpStatus('OK')).json({
          success: true,
          data: { ...user },
          message: utility.getMessage(req, false, 'LOGIN_SUCCESS'),
        });
      } else {
        await userActivityRepository.createActivity('login', 'unauthorized', req?.ip, null);
        res.status(utility.httpStatus('BAD_REQUEST')).json({
          success: false,
          data: null,
          message: utility.getMessage(req, false, 'WRONG_CREDENTIAL'),
        });
      }
    } else {
      await userActivityRepository.createActivity('login', 'unauthorized', req?.ip, null);
      res.status(utility.httpStatus('BAD_REQUEST')).json({
        success: false,
        data: null,
        message: utility.getMessage(req, false, 'WRONG_CREDENTIAL'),
      });
    }
  } catch (error) {
    next(error);
  }
};


module.exports.logout = async (req, res, next) => {
  try {
    const { userToken, user } = req;
    const userDevice = await accountRepository.logoutUser(
      userToken?.id,
      user?.id
    );
    if (userDevice) {
      await userActivityRepository.createActivity('logout', 'authorized', req?.ip, user?.id);
      res.status(utility.httpStatus('OK')).json({
        success: true,
        data: {},
        message: utility.getMessage(req, false, 'LOGOUT_SUCCESS'),
      });
    } else {
      userActivityRepository.createActivity('logout', 'unauthorized', req?.ip, null);
      res.status(utility.httpStatus('BAD_REQUEST')).json({
        success: false,
        data: null,
        message: utility.getMessage(req, false, 'USER_NOT_FOUND'),
      });
    }
  } catch (error) {
    next(error);
  }
};


module.exports.getUserDetail = async (req, res, next) => {
  try {
    const { user } = req;
    delete user.dataValues.password;
    delete user.dataValues.oldPassword;
    res.status(utility.httpStatus('OK')).json({
      success: true,
      data: user,
      message: utility.getMessage(req, false, 'USER_DETAIL'),
    });
  } catch (error) {
    next(error);
  }
};


module.exports.socialLogin = async (req, res, next) => {
  try {
    const result = await accountRepository.updateToken(req?.user);
    if (result) {
      res.redirect(`${process.env.ClIENT_BASEURL}/callback?token=${result.token}`);
    } else {
      res.status(utility.httpStatus('BAD_REQUEST')).json({
        success: false,
        data: null,
        message: utility.getMessage(req, false, 'WRONG_CREDENTIAL'),
      });
    }
  } catch (error) {
    next(error);
  }
}