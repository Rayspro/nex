const repositories = require('../repositories/index.js');
const utility = require('../../utils/index.js');

const { userActivityRepository } = repositories;

module.exports.getUserActivity = async (req, res) => {
  try {
    const { id } = req.params;
    const { page = 1, pageSize = 10 } = req.query;

    const result = await userActivityRepository.getUserActivity(id, parseInt(page), parseInt(pageSize));

    if (result) {
      res.status(utility.httpStatus('OK')).json({
        success: true,
        data: result,
        message: utility.getMessage(req, false, 'USER_DETAIL'),
      });
    } else {
      res.status(utility.httpStatus('BAD_REQUEST')).json({
        success: false,
        data: null,
        message: "No User Activities Found"
      });
    }
  } catch (error) {
    console.error(error);
    res.status(utility.httpStatus('INTERNAL_SERVER_ERROR')).json({
      success: false,
      message: "An error occurred while fetching user activities",
    });
  }
};