const { createUser, getUsers, updateUser } = require('../repositories/user.repository.js');
const utility = require('../../utils/index.js');

module.exports.createUser = async (req, res) => {
  const { body, user } = req;
  try {
    const result = await createUser(body.fName, body.lName, body.email, user.id, body.password, body?.ipAddresses, body.restrictionType);
    if (result) {
      res.status(utility.httpStatus('OK')).json({
        success: true,
        data: {},
        message: utility.getMessage(req, false, 'SIGNUP'),
      });
    } else {
      res.status(utility.httpStatus('BAD_REQUEST')).json({
        success: false,
        data: null,
      });
    }
  } catch (error) {
    throw Error(error);
  }
}

module.exports.updateUser = async (req, res) => {
  const { body, user } = req;
  const { id } = req.params;
  try {
    if (!body.restrictionType) {
      body.restrictionType = "public"
    }
    const result = await updateUser(id, body.fName, body.lName, user.id, body.password, body?.ipAddresses, body?.restrictionType);
    if (result) {
      res.status(utility.httpStatus('OK')).json({
        success: true,
        data: {},
        message: utility.getMessage(req, false, 'SIGNUP'),
      });
    } else {
      res.status(utility.httpStatus('BAD_REQUEST')).json({
        success: false,
        data: null,
      });
    }
  } catch (error) {
    throw Error(error);
  }
}



module.exports.getUsers = async (req, res) => {
  try {
    const { page = 1, pageSize = 10 } = req.query;
    const result = await getUsers(parseInt(page), parseInt(pageSize));

    if (result) {
      res.status(utility.httpStatus('OK')).json({
        success: true,
        data: result,
        message: "User Fetched Successfully"
      });
    } else {
      res.status(utility.httpStatus('BAD_REQUEST')).json({
        success: false,
        data: null,
      });
    }
  } catch (error) {
    console.log(error)
    throw Error(error);
  }
}