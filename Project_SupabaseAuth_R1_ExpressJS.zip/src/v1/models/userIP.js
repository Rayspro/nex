/**
 * Define the UserLoginLog model using Sequelize.
 * @param {object} sequelize - The Sequelize instance
 * @param {object} DataTypes - The data types provided by Sequelize
 * @returns {object} - The UserLoginLog model
 */

module.exports = (sequelize, DataTypes) => {
  const UserIp = sequelize.define(
    'UserIp',
    {
      userId: {
        type: DataTypes.INTEGER,
      },
      imposedBy: {
        type: DataTypes.INTEGER,
      },
      allowedIp: {
        type: DataTypes.STRING,
      },
      restrictionType: {
        type: DataTypes.ENUM('custom-ip', 'company-ip', 'public'),
      },
    },
    {
      underscored: true,
    }
  );
  UserIp.associate = (models) => {
    UserIp.belongsTo(models.User, {
      foreignKey: 'userId',
    });
    UserIp.belongsTo(models.User, {
      foreignKey: 'imposedBy',
    });
  };
  return UserIp;
};
