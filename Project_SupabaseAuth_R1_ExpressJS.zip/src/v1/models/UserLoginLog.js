/**
 * Define the UserLoginLog model using Sequelize.
 * @param {object} sequelize - The Sequelize instance
 * @param {object} DataTypes - The data types provided by Sequelize
 * @returns {object} - The UserLoginLog model
 */

module.exports = (sequelize, DataTypes) => {
  const UserLoginLog = sequelize.define(
    'UserLoginLog',
    {
      userId: {
        type: DataTypes.INTEGER,
      },
      loginDate: {
        type: DataTypes.DATE,
      },
      logoutDate: {
        type: DataTypes.DATE,
      },
      ip: {
        type: DataTypes.STRING,
      },
    },
    {
      underscored: true,
    }
  );
  UserLoginLog.associate = (models) => {
    UserLoginLog.belongsTo(models.User, {
      foreignKey: 'userId',
    });
  };
  return UserLoginLog;
};
