/**
 * Define the UserLoginLog model using Sequelize.
 * @param {object} sequelize - The Sequelize instance
 * @param {object} DataTypes - The data types provided by Sequelize
 * @returns {object} - The UserLoginLog model
 */

module.exports = (sequelize, DataTypes) => {
  const UserActivity = sequelize.define(
    'UserActivity',
    {
      userId: {
        type: DataTypes.INTEGER,
      },
      activityType: {
        type: DataTypes.ENUM('login', 'logout', 'signup', 'forgotPassword'),
      },
      ip: {
        type: DataTypes.STRING,
      },
      activityStatus: {
        type: DataTypes.ENUM('authorized', 'unauthorized', 'error'),
      },
    },
    {
      underscored: true,
    }
  );
  UserActivity.associate = (models) => {
    UserActivity.belongsTo(models.User, {
      foreignKey: 'userId',
    });
  };
  return UserActivity;
};
