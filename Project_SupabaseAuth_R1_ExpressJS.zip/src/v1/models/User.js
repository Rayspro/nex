const { Op } = require('sequelize');
const config = require('../../config/index.js');
const utility = require('../../utils/index.js');

const defaultUserImage = `${config.app.baseUrl}public/default-images/defaultProfileImage.png`;
/**
 * Define the User model using Sequelize.
 * @param {object} sequelize - The Sequelize instance
 * @param {object} DataTypes - The data types provided by Sequelize
 * @returns {object} - The User model
 */
module.exports = (sequelize, DataTypes) => {
  const User = sequelize.define(
    'User',
    {
      firstName: {
        type: DataTypes.STRING(100),
      },
      lastName: {
        type: DataTypes.STRING(100),
      },
      email: {
        type: DataTypes.STRING(100),
      },
      phoneNumber: {
        type: DataTypes.STRING(16),
      },
      password: {
        type: DataTypes.STRING(255),
      },
      resetPasswordToken: {
        type: DataTypes.STRING(255),
      },
      providerId: {
        type: DataTypes.STRING,
        allowNull: true
      },
      provider: {
        type: DataTypes.STRING,
        allowNull: true
      },
      // displayName: {
      //   type: DataTypes.STRING,
      //   allowNull: true
      // },
      // restrictionType: {
      //   type: DataTypes.ENUM('custom-ip', 'org-ip', 'public'),
      //   allowNull: true
      // },
      // allowedIp: {
      //   type: DataTypes.STRING,
      //   allowNull: true
      // },
      status: {
        type: DataTypes.ENUM('active', 'inactive', 'deleted'),
        defaultValue: 'active',
      },
    },
    {
      underscored: true,
    }
  );

  User.loadScopes = () => {
    User.addScope('basic', {
      where: {
        status: 'active',
      },
      attributes: {
        exclude: ['password', 'token'],
      },
    });
    User.addScope('activeUser', {
      where: {
        status: 'active',
      },
      attributes: {
        exclude: ['password', 'token'],
      },
    });

    User.addScope('notDeletedUser', {
      where: {
        status: { [Op.ne]: 'deleted' },
      },
      attributes: {
        exclude: ['password', 'token'],
      },
    });
    User.addScope('inactive', {
      where: {
        status: 'inactive',
      },
      attributes: {
        exclude: ['password', 'token'],
      },
    });
    User.addScope('deletedUser', {
      attributes: {
        exclude: ['password', 'token'],
      },
    });
  };

  User.associate = (models) => {
    User.hasMany(models.UserIp, {
      foreignKey: 'userId',
    });
    User.hasOne(models.UserIp, {
      foreignKey: 'imposedBy'
    });
  };
  return User;
};
