const { Router } = require('express');
const middlewares = require('../middlewares/index.js');
const { getUserActivity } = require('../controllers/user-activity.controller.js');

const {
  authMiddleware,
} = middlewares;

const router = Router();

router.get("/user-activity/:id", authMiddleware, getUserActivity)

module.exports = router; 