const { Router } = require('express');
const account = require('./account.js');
const user = require('./user.js');
const userActivity = require('./user-activity.js');

const router = Router();
// Route for handling page not found
const register = (app) => {
  app.use(router);
  app.get('*', (res) => {
    res.render('pageNotFound');
  });
  // API routes
  router.use('/api/v1', [account, user, userActivity]);
}
module.exports = register;
