const { Router } = require('express');

const validations = require('../validations/index.js');
const middlewares = require('../middlewares/index.js');
const { createUser, getUsers, updateUser } = require('../controllers/user.controller.js');

const { accountValidator } = validations;
const {
  validateMiddleware,
  accountMiddleware,
  authMiddleware,
} = middlewares;

const router = Router();

router.post("/employee", authMiddleware, validateMiddleware(accountValidator.userAccountSignupSchema), accountMiddleware.checkEmailExists, createUser);

router.put("/employee/:id", authMiddleware, validateMiddleware(accountValidator.userUpdateSchema), updateUser);

router.get("/employee", authMiddleware, getUsers)

module.exports = router;