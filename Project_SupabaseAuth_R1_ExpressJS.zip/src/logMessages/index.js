// Importing message modules
const commonMessage = require('./common.message.js');
const emailMessage = require('./email.message.js');
const accountMessage = require('./account.message.js');
const mediaMessage = require('./media.message.js');
const emailTemplateMessage = require('./emailTemplate.message.js');
// Exporting all message modules
module.exports = {
  ...emailMessage,
  ...commonMessage,
  ...accountMessage,
  ...mediaMessage,
  ...emailTemplateMessage,
};
