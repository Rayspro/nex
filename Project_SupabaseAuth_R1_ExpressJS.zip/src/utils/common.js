const path = require('path');
const fs = require('fs');
const httpStatus = require('http-status');
const language = require('../language/index.js');
const environment = require('./environment.js');

exports.httpStatus = (status) => {
  try {
    return httpStatus[status];
  } catch (error) {
    throw new Error(error);
  }
};
exports.generateRandomString = (length) => {
  try {
    let chars = 'klmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    chars = `${chars}0123456789abcdefghij`;
    let output = '';

    for (let x = 0; x < length; x += 1) {
      const i = Math.floor(Math.random() * 62);
      output += chars.charAt(i);
    }
    return output;
  } catch (error) {
    throw new Error(error);
  }
};

// Function to check if a file exists
exports.isFileExist = (filePath) => {
  try {
    const tmpPath = path.join(path.resolve(), `${filePath}`);
    return fs.existsSync(tmpPath) || false;
  } catch (error) {
    throw new Error(error);
  }
};
function getThumbUrl(str, thumbImage) {
  try {
    // const { aws } = config;
    let http;
    if (environment.getEnv('NODE_ENV') === 'production') {
      http = 'https';
    } else {
      http = 'http';
    }
    const imagePathArray = str.split('/');
    const imageName = imagePathArray.pop();
    let thumbPath = path.parse(imageName);
    thumbPath = `${thumbPath.dir ? `${thumbPath.dir}/` : ''}thumb/${
      thumbPath.base
    }`;
    imagePathArray.push(thumbImage ? thumbPath : imageName);
    return `${http}://${environment.getEnv(
      'SWAGGER_HOST'
    )}/${imagePathArray.join('/')}`;
  } catch (err) {
    throw new Error(err);
  }
}

// Function to get the image URL
exports.getImage = (str, defaultIcon, thumbImage = false) => {
  try {
    if (str) {
      const imagePathArray = str.split('/');
      const imageName = imagePathArray.pop();
      let http;
      if (environment.getEnv('NODE_ENV') === 'production') {
        http = 'https';
      } else {
        http = 'http';
      }
      let thumbPath = path.parse(imageName);
      thumbPath = `${thumbPath.dir}/thumb/${thumbPath.base}`;
      imagePathArray.push(thumbImage ? thumbPath : imageName);
      if (this.isFileExist(str)) {
        if (thumbImage) {
          return getThumbUrl(str, 'public', 'local', thumbImage);
        }
        return `${http}://${environment.getEnv(
          'SWAGGER_HOST'
        )}/${imagePathArray.join('/')}`;
      }
      return defaultIcon;
    }
    return defaultIcon;
  } catch (error) {
    throw new Error(error);
  }
};

// Function to get the thumbnail URL
// function getThumbUrl(str, thumbImage) {
//   try {
//     // const { aws } = config;
//     const http =
//       environment.getEnv('NODE_ENV') === 'production' ? 'https' : 'http';
//     const imagePathArray = str.split('/');
//     const imageName = imagePathArray.pop();
//     let thumbPath = path.parse(imageName);
//     thumbPath = `${thumbPath.dir ? `${thumbPath.dir}/` : ''}thumb/${
//       thumbPath.base
//     }`;
//     imagePathArray.push(thumbImage ? thumbPath : imageName);
//     return `${http}://${environment.getEnv(
//       'SWAGGER_HOST'
//     )}/${imagePathArray.join('/')}`;
//   } catch (err) {
//     console.log(err);
//   }
// }
// Function to get language-based messages
exports.getMessage = (req, data, key) => {
  try {
    let languageCode = req.headers && req.headers.language;
    languageCode = languageCode || 'en';
    const condition = language[languageCode] && language.en[`${key}`];
    if (data) {
      return condition ? language[languageCode][`${key}`](data) : key;
    }
    return condition ? language[languageCode][`${key}`] : key;
  } catch (error) {
    throw new Error(error);
  }
};

// Function to convert JSON to string
exports.jsonToString = (obj = {}) => {
  try {
    if (obj && typeof obj === 'object' && Object.keys(obj).length !== 0) {
      return JSON.stringify(obj);
    }
    return Object.keys(obj).length === 0 ? String(obj) : obj;
  } catch (error) {
    throw new Error(error);
  }
};
// Function to convert JSON string to object
exports.jsonToParse = (obj = '') => {
  try {
    if (obj && typeof obj === 'string') {
      return JSON.parse(obj);
    }
    return obj ?? {};
  } catch (error) {
    throw new Error(error);
  }
};
// Function to get values from a schema
module.exports.schemaValueGet = (value, schema) => {
  try {
    const final = [];
    value.forEach((e) => final.push({ [e]: schema[e] }));
    return Object.assign(...final);
  } catch (error) {
    throw new Error(error);
  }
};
