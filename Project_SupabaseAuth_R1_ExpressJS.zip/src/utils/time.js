const { DateTime } = require('luxon');
const dayjs = require('dayjs');
const utc = require('dayjs/plugin/utc');
const timezone = require('dayjs/plugin/timezone');
const customParseFormat = require('dayjs/plugin/customParseFormat');

dayjs.extend(customParseFormat);
dayjs.extend(utc);
dayjs.extend(timezone);

/**
 * get current date
 * @returns CURRENT DATE
 */
module.exports.getCurrentDate = (date, format) => {
  return DateTime.local(...this.getDateTimeData(date ?? Date())).toFormat(
    format ?? 'yyyy-MM-dd HH:mm:ss'
  );
};

/**
 * get current date
 * @returns CURRENT DATE
 */
module.exports.getDateTimeFormat = (date, format) => {
  return DateTime.local(...this.getDateTimeData(date ?? Date())).toFormat(
    format ?? 'yyyy-MM-dd HH:mm:ss'
  );
};

// to find current date
module.exports.getCurrentDate = () => {
  return new Date();
};
