const schedule = require('node-schedule');
const appInstance = require('./app.js');
const services = require('./services/index.js');
const { loggerInfoMessage } = require('./logMessages/index.js');
const config = require('./config/index.js');

const { database, serverError } = services;
appInstance().then((app) => {
  const port = app.get('port');
  app.listen(port, async () => {
    loggerInfoMessage('listen', { port });
    database();
  });
});

process.on('uncaughtExceptionMonitor', (err) => {
  if (err) {
    serverError.serverErrorLog(err);
  }
});

process.on('unhandledRejection', (reason, promise) => {
  if (reason) {
    serverError.serverErrorLog(reason, promise);
  }
});
