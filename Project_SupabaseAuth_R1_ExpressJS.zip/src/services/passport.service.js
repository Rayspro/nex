const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const FacebookStrategy = require('passport-facebook').Strategy;
const TwitterStrategy = require('passport-twitter').Strategy;
const models = require('../v1/models/index');
const jwt = require('../services/jwt.service.js');

const { User } = models;

// Google
passport.use(new GoogleStrategy({
  clientID: process.env.GOOGLE_CLIENT_ID,
  clientSecret: process.env.GOOGLE_CLIENT_SECRET,
  callbackURL: `${process.env.SERVER_BASE_URL}/v1/auth/google/callback`
}, async (accessToken, refreshToken, profile, done) => {
  try {
    const [user, created] = await User.findOrCreate({
      where: { providerId: profile.id, provider: 'google' },
      defaults: {
        displayName: profile.displayName,
        name: profile.displayName,
        firstName: profile.displayName,
        lastName: profile.displayName,
        email: profile.emails[0].value
      }
    });

    const token = await jwt.createToken({ id: user.id, displayName: user.displayName, email: user.email })
    return done(null, { ...user, token });
  } catch (err) {
    return done(err);
  }
}));

// Facebook
passport.use(new FacebookStrategy({
  clientID: process.env.FACEBOOK_CLIENT_ID,
  clientSecret: process.env.FACEBOOK_CLIENT_SECRET,
  callbackURL: `${process.env.SERVER_BASE_URL}/v1/auth/facebook/callback`,
  profileFields: ['id', 'displayName', 'emails']
}, async (accessToken, refreshToken, profile, done) => {
  try {
    const [user, created] = await User.findOrCreate({
      where: { providerId: profile.id, provider: 'facebook' },
      defaults: {
        displayName: profile.displayName,
        name: profile.displayName,
        email: profile.emails ? profile.emails[0].value : null
      }
    });

    const token = await jwt.createToken({ id: user.id, displayName: user.displayName, email: user.email })
    return done(null, { ...user, token });
  } catch (err) {
    return done(err);
  }
}));

// // Twitter
// passport.use(new TwitterStrategy({
//   consumerKey: process.env.TWITTER_CONSUMER_KEY,
//   consumerSecret: process.env.TWITTER_CONSUMER_SECRET,
//   callbackURL: "http://localhost:5000/auth/twitter/callback",
//   includeEmail: true
// }, async (accessToken, refreshToken, profile, done) => {
//   try {
//     const [user, created] = await User.findOrCreate({
//       where: { providerId: profile.id, provider: 'twitter' },
//       defaults: {
//         displayName: profile.displayName,
//         name: profile.displayName,
//         email: profile.emails ? profile.emails[0].value : null
//       }
//     });

//     const token = jwt.sign({ id: user.id, displayName: user.displayName, email: user.email }, process.env.JWT_SECRET, { expiresIn: '1h' });
//     return done(null, { user, token });
//   } catch (err) {
//     return done(err);
//   }
// }));