const logger = require('./logger.service.js');
const database = require('./database.service.js');
const swagger = require('./swagger.service.js');
const multerStorageService = require('./multer.service.js');
const ejs = require('./ejs.service.js');
const email = require('./email.service.js');
const moduleKey = require('./module-key.service.js');
const serverError = require('./sever-error.service.js');
// Exporting all service modules
module.exports = {
  logger,
  database,
  swagger,
  ejs,
  multerStorageService,
  email,
  moduleKey,
  serverError,
};
