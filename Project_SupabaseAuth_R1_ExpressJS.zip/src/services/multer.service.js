/* eslint-disable security/detect-non-literal-fs-filename */
const fs = require('fs');
const path = require('path');
const multer = require('multer');
const config = require('../config/index.js');
// Allowed file formats for different media types
const allowedFormats = {
  image: ['.png', '.jpg', '.gif', '.jpeg'],
  video: ['.mp4', '.mov', '.wmv', '.avi'],
  doc: [
    '.pdf',
    '.html',
    '.ppt',
    '.pptx',
    '.xlsx',
    '.png',
    '.jpg',
    '.gif',
    '.jpeg',
  ],
  audio: ['.aac', '.m4a', '.mp3'],
};

// Allowed file formats for file storage
const format = [
  'jpeg',
  'png',
  'jpg',
  'docx',
  'xlsx',
  'csv',
  'doc',
  'mp3',
  'mp4',
  'pdf',
];

// Define storage for multer
const storage = multer.diskStorage({
  destination: async (req, file, cb) => {
    const {
      params: { mediaFor },
    } = req;
    const fileDir = path.join(
      path.resolve(),
      `/public/uploads/${mediaFor}/thumb`
    );
    if (!fs.existsSync(fileDir)) {
      fs.mkdirSync(fileDir, { recursive: true }, (err) => {
        throw Error(err);
      });
    }
    cb(null, `public/uploads/${mediaFor}/`);
  },
  filename: (_req, file, cb) => {
    const {
      params: { dateTimestamp },
    } = _req;
    const filename = file.originalname.replace(/[^A-Z0-9.]/gi, '-');
    const fileArray = filename.split('.');
    const ext = fileArray.pop();
    cb(null, `${fileArray.join('-')}-${dateTimestamp}.${ext}`);
  },
});

// Function to get storage configuration for multer
async function getStorage() {
  return multer({
    storage,
    fileFilter: (req, file, callback) => {
      let fileFormats = [];
      const {
        params: { mediaType },
      } = req;
      const ext = path.extname(file.originalname);
      if (mediaType === 'image') {
        fileFormats = allowedFormats.image;
      } else if (mediaType === 'video') {
        fileFormats = allowedFormats.video;
      } else if (mediaType === 'doc') {
        fileFormats = allowedFormats.doc;
      } else if (mediaType === 'audio') {
        fileFormats = allowedFormats.audio;
      }
      if (!fileFormats.includes(ext.toLowerCase())) {
        return callback(new Error('Invalid file format.'));
      }
      callback(null, true);
    },
    limits: {
      fileSize: config.app.mediaUploadSizeLimit,
    },
  });
}

// Function to get file storage configuration for multer
async function getFileStorage(type = 'local') {
  return multer({
    storage: type === 'local',
    fileFilter: (_req, file, callback) => {
      const ext = path.extname(file.originalname).split('.').pop();
      if (!format.includes(ext.toLowerCase())) {
        return callback(
          new Error(`Incorrect file format ${format.toString()}.`)
        );
      }
      callback(null, true);
    },
    limits: {
      fileSize: config.app.mediaUploadSizeLimit,
    },
  });
}

module.exports = {
  getStorage,
  getFileStorage,
};
