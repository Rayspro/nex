const { loggerErrorMessage } = require('../logMessages/index.js');
// Export function to log server errors
module.exports.serverErrorLog = async (error) => {
  try {
    loggerErrorMessage({ error });
  } catch (err) {
    loggerErrorMessage({ error: err });
    return false;
  }
};
