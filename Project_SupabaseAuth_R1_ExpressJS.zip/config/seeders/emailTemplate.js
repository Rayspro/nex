/* eslint-disable*/
// Define constant for the table name
const table = "email_templates";
// Array containing email template objects
const listArray = [
  {
    emailCode: "USER_RESET_PASSWORD",
    emailType: "html",
    emailSubject: "Password Request for rest password",
    emailBody:
      "Dear #NAME#,<br><br>We got a request to reset your password.<br><br>You can reset your password by clicking the link below: <br><br> #LINK#<br><br><span>If you ignore this message, your password will not be changed. If you didn't request a password reset, let us know.<br></span><br>Thanks!<br><br><br>",
  },
  {
    emailCode: "USER_FORGOT_PASSWORD",
    emailType: "html",
    emailSubject: "Password Request",
    emailBody:
      "Below is the requested email and the password. <br><br>Email: #EMAIL# <br>Password: #Password# <br><br>We look forward to a long association with you. <br><br>Thanks!",
  },
];

// Exporting migration functions
module.exports = {
  up: async (queryInterface) => {
    try {
      let templateId = null;
      const arr = listArray.map(
        (item) =>
          new Promise(async (resolve) => {
            // check if email template already exists
            templateId = await queryInterface.rawSelect(
              "email_templates",
              {
                where: {
                  email_code: item.emailCode,
                },
              },
              ["id"],
            );
            if (!templateId) {
              templateId = await queryInterface.bulkInsert(
                table,
                [
                  {
                    subject: item?.emailSubject,
                    body: item?.emailBody,
                    email_code: item?.emailCode,
                    mime_type: item?.emailType,
                    status: "active",
                    created_at: new Date(),
                    updated_at: new Date(),
                  },
                ],
                {},
              );
              resolve();
            }
            resolve();
          }),
      );
      // Execute all promises concurrently
      await Promise.all(arr);
    } catch (err) {
      // Handle errors during migration
      console.log(err, "Seeder error");
    }
  },
  // Migration function for reverting changes from the database
  down: (queryInterface) => queryInterface.bulkDelete(table, null, {}),
};
