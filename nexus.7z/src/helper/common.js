/**
 * Utility module for handling errors and other common functionalities.
 * @module utility
 */
const utility = require('../utils/index.js');

/**
 * Returns an error instance with a specified message and status type.
 * @param {string} msg - The error message.
 * @param {string} [type='BAD_REQUEST'] - The status type of the error. Defaults to 'BAD_REQUEST'.
 * @returns {Error} - The error instance.
 */
module.exports.getErrorInstance = (msg, type) => {
  try {
    const err = new Error(msg);
    err.status = utility.httpStatus(type || 'BAD_REQUEST');
    return err;
  } catch (err) {
    return err;
  }
};

/**
 * Resolves promises synchronously with a specified function and data.
 * @param {Object} data - The data object containing the array to iterate over.
 * @param {Function} fn - The function to be executed synchronously.
 * @param {number} currentIndex - The current index of the array being processed.
 * @returns {boolean} - Indicates whether the synchronous resolution is complete.
 */
module.exports.syncResolve = async (data, fn, currentIndex) => {
  const { arr } = data;
  const limit = 5;
  if (arr.length <= currentIndex || currentIndex === limit) {
    return true;
  }
  await fn(data, currentIndex);
  this.syncResolve(data, fn, currentIndex + 1);
};

/**
 * Extracts the error string from an error object or stack trace.
 * @param {*} err - The error object or stack trace.
 * @param {string} [defaultMessage] - The default message to return if the extraction fails.
 * @returns {string} - The extracted error string.
 */
module.exports.getErrorString = (err, defaultMessage) => {
  try {
    const errStack = (err?.stack || err || '').split('\n');
    if (errStack.length > 0) {
      return (errStack[0] || '')?.split(':').pop();
    }
    return defaultMessage || err;
  } catch {
    return defaultMessage || err;
  }
};
