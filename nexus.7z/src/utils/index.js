const timeUtil = require('./time.js');
const commonUtil = require('./common.js');
const environmentUtil = require('./environment.js');

// Exporting all utility functions by merging them
module.exports = {
  ...timeUtil,
  ...commonUtil,
  ...environmentUtil,
  ...environmentUtil,
};
