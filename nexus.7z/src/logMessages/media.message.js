const { logger } = require('../services/logger.service.js');
const { jsonToString } = require('../utils/common.js');
/**
 * Logs media-related error messages.
 * @param {string} type - Type of media error.
 * @param {object} object - Object containing error details.
 */
exports.mediaErrorMessage = (type, object) => {
  const { data, bodyData } = object;
  const error = jsonToString(object?.error);
  const payload = jsonToString(data ?? bodyData);
  let message = '';
  switch (type) {
    case 'pendingMediaRemove':
      message = `Media find all and remove error: ${error}`;
      break;
    case 'unlinkLocal':
      message = `Media unlink media from local error: ${error}, payload: ${payload}`;
      break;
    case 'uploadMedia':
      message = `Upload media error: ${error}, payload: ${payload}`;
      break;
    case 'mediaValidation':
      message = `Media validation error: ${error}`;
      break;
    case 'mediaCreate':
      message = `Media file create error: ${error}, payload: ${payload}`;
      break;
    case 'multipleCreate':
      message = `Media file create multiple error: ${error}, payload: ${payload}`;
      break;
    case 'findBasePath':
      message = `Media find all by base path error: ${error}, payload: ${payload}`;
      break;
    case 'unlink':
      message = `Media find media by base path and unlink error: ${error}, payload: ${payload}`;
      break;
    case 'mediaUsed':
      message = `Media used error: ${error}, payload: ${payload}`;
      break;
    case 'mediaPending':
      message = `Media mark media as pending error: ${error}, payload: ${payload}`;
      break;
    case 'singledUrl':
      message = `Media get singled url error: ${error}, payload: ${payload}`;
      break;
    case 'checkMedia':
      message = `bucket  error: ${error}, payload: ${data}`;
      break;
    default:
      message = `Media error ${error}`;
      break;
  }
  logger('mediaError').error(new Error(message));
};
