// Function to log account-related error messages
const { logger } = require('../services/logger.service.js');
const { jsonToString } = require('../utils/common.js');

/**
 * Logs account-related error messages.
 * @param {string} type - Type of error.
 * @param {object} object - Object containing relevant data for error message.
 */
exports.accountErrorMessage = (type, object) => {
  const { data, userId, password, whereObj, bodyData, id } = object;
  const error = jsonToString(object?.error);

  const payload = jsonToString(data ?? bodyData);
  let message = '';

  // Determine error type and construct appropriate message
  switch (type) {
    case 'deviceDetailByToken':
      message = `Account get device detail by token error: ${error}, payload: ${payload}`;
      break;
    case 'createHashPassword':
      message = `Account create hash password error: ${error}, password: ${password}`;
      break;
    case 'signup':
      message = `Account signup error: ${error}, payload: ${payload}`;
      break;
    case 'addDevice':
      message = `Account add update user device error: ${error}, payload: ${payload}`;
      break;
    case 'webLogin':
      message = `Account user account login error: ${error}, payload: ${payload}`;
      break;
    case 'signupLogin':
      message = `Customer signup user account login error: ${error}, payload: ${payload}`;
      break;
    case 'userDetails':
      message = `Account find one error: ${error}, where: ${jsonToString(
        whereObj
      )}`;
      break;
    case 'resentLink':
      message = `Account send reset password link error: ${error}, payload: ${payload}`;
      break;
    case 'caratePassword':
      message = `Account password reset error: ${error}, payload: ${payload}`;
      break;
    case 'resetPassword':
      message = `Account reset password error: ${error}, payload: ${payload}`;
      break;
    case 'changePassword':
      message = `Account change password error: ${error}, payload: ${payload}`;
      break;
    case 'editProfile':
      message = `Account edit profile error: ${error}, payload: ${payload}`;
      break;
    case 'loginDeviceCount':
      message = `User login device count error: ${error}, userId: ${userId}`;
      break;
    case 'logoutUser':
      message = `User account logout error: ${error}, id: ${id}`;
      break;
    default:
      message = `Account error ${error}`;
      break;
  }

  // Log the error message using logger service
  logger('accountError').error(new Error(message));
};
