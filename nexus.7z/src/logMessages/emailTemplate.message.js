const { logger } = require('../services/logger.service.js');
const { jsonToString } = require('../utils/common.js');

/**
 * Logs email template-related error messages.
 * @param {string} type - Type of email template error.
 * @param {object} object - Object containing error details.
 */
exports.emailTemplateMessage = (type, object) => {
  const { data, where, bodyData } = object;
  const error = jsonToString(object?.error);
  const payload = jsonToString(data ?? bodyData);
  let message = '';
  switch (type) {
    case 'emailTemplateAdd':
      message = `Email template add error: ${error}, payload: ${payload}`;
      break;
    case 'list':
      message = `Email template list error: ${error}, payload: ${payload}`;
      break;
    case 'details':
      message = `Email template details error: ${error}, where: ${jsonToString(
        where
      )}`;
      break;
    case 'editEmailTemplate':
      message = `Email template details update error: ${error}, payload: ${payload}`;
      break;
    case 'emailTemplateStatus':
      message = `Status update error: ${error}, payload: ${payload}`;
      break;
    case 'templateGenerate':
      message = `Email template generate error: ${error}, payload: ${payload}`;
      break;
    case 'templateGet':
      message = `Email template get error: ${error}, payload: ${payload}`;
      break;
    case 'templateDataReplace':
      message = `Email template replace content error: ${error}, payload: ${payload}`;
      break;
    default:
      message = `Email template error ${error}`;
      break;
  }
  // Log email template-related error message
  logger('emailTemplateError').error(new Error(message));
};
