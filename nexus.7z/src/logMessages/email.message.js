const { logger } = require('../services/logger.service.js');
const { jsonToString } = require('../utils/common.js');
/**
 * Logs email-related error messages.
 * @param {string} type - Type of email error.
 * @param {object} object - Object containing error details.
 */
exports.emailErrorMessage = (type, object) => {
  const { data, bodyData } = object;
  const error = jsonToString(object?.error ?? object?.error?.message);
  const payload = jsonToString(data ?? bodyData);
  let message = '';
  switch (type) {
    case 'email':
      message = `Unable to send to email, error: ${error}`;
      break;
    case 'emailError':
      message = `Send to email server, error: ${error}`;
      break;
    case 'forgotPasswordTemplate':
      message = `Send to email server, error: ${error}, payload: ${payload}`;
      break;
    case 'deepLink':
      message = `Deep link generate error: ${error}, payload: ${payload}`;
      break;
    case 'verifyEmailServer':
      message = `Verify Email Server error: ${error}, payload: ${payload}`;
      break;
    case 'sesEmailError':
      message = `Ses email error: ${error}, payload: ${payload}`;
      break;
    default:
      message = `Unable to connect to email server' ${error}`;
      break;
  }
  logger('emailError').error(new Error(message));
};
