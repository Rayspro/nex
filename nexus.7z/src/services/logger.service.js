const winston = require('winston');
const path = require('path');
require('winston-daily-rotate-file');

const datePattern = 'YYYY-MM-DD';
// Function to create a logger instance
function createLogger(transport, level) {
  return winston.createLogger({
    level: level || 'info',
    format: winston.format.combine(
      winston.format.timestamp(),
      winston.format.errors({ stack: true }),
      winston.format.json()
    ),
    transports: [transport],
  });
}
// Function to create a daily rotating logger
function dailyLogger(object) {
  const { name, level } = object;
  const transport = new winston.transports.DailyRotateFile({
    name,
    filename: path.join(__dirname, '../', 'logs/%DATE%', `${name}.log`),
    datePattern,
    maxFiles: '5d',
  });
  return createLogger(transport, level);
}
module.exports.logger = (data) => dailyLogger({ name: data });
