const nodemailer = require('nodemailer');
const emailConfig = require('../config/email.js');
const {
  app: { mailSenderType },
} = require('../config/index.js');
const { emailErrorMessage } = require('../logMessages/index.js');

const transport = nodemailer.createTransport(emailConfig.smtp);
const { fromEmail } = emailConfig;
/**
 * Verify smtp details
 */
module.exports.verifyEmailServer = async (options) => {
  try {
    if (mailSenderType === 'SMTP' && !options?.isgConfig) {
      const result = await transport.verify();
      if (result) {
        return await this.sendEmail(options);
      }
    }
    return false;
  } catch (error) {
    emailErrorMessage('verifyEmailServer', { error });
    throw Error(error);
  }
};

/**
 * Send email
 * @param {Object} options
 */
module.exports.sendEmail = (options) => {
  try {
    const mailOptions = {
      ...options,
      from: fromEmail,
      html: options?.message,
    };
    // File attachment
    if (options.attachments) {
      mailOptions.attachments = options.attachments;
    }
    // BCC users mail send
    if (options.bcc) {
      mailOptions.bcc = options.bcc;
    }
    // CC users mail send
    if (options.cc) {
      mailOptions.cc = options.cc;
    }
    return new Promise((resolve, reject) => {
      transport.sendMail(mailOptions, (error, info) => {
        if (error) {
          emailErrorMessage('email', { error });
          reject(error);
        } else {
          resolve(info);
        }
      });
    });
  } catch (error) {
    emailErrorMessage('emailError', { error });
  }
};
