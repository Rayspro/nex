const models = require('../v1/models/index.js');
// Importing logger functions for error and information messages
const {
  loggerErrorMessage,
  loggerInfoMessage,
} = require('../logMessages/index.js');

/**
 * Function to establish database connection, authenticate, and synchronize models.
 */
function establishDbConnection() {
  const { sequelize } = models;
  sequelize
    .authenticate()
    .then(async () => {
      loggerInfoMessage('connection');
      console.log('Database connected successfully');
      await sequelize
        .sync()
        .then(() => {
          loggerInfoMessage('sync');
        })
        .catch((error) => {
          console.log('err', error);
          loggerErrorMessage('sync', { error });
        });
    })
    .catch((error) => {
      console.log('err', error);
      loggerErrorMessage('connection', { error });
      // console.log('Database connection error %s', error);
    });
}

module.exports = establishDbConnection;
