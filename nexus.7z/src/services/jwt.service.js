const jwt = require('jsonwebtoken');
const config = require('../config/index.js');
// Exporting functions related to JWT token manipulation

module.exports = {
  async createToken(payload) {
    return await jwt.sign(payload, config.jwtSecret, {
      expiresIn: config.jwtExpireIn,
    });
  },

  verifyToken(token) {
    return jwt.verify(token, config.jwtSecret);
  },
  decodeToken(token) {
    return jwt.decode(token, {
      complete: true,
    });
  },
};
