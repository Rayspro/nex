const moduleKey = {
  /**
   * Media uploader
   */
  MEDIA_UPLOAD: {
    key: 'media-upload',
    slug: '/media/upload/:mediaFor',
  },
  MEDIA_UPLOAD_USED: {
    key: 'media-upload',
    slug: '/media/upload-used/:mediaFor',
  },
  PUBLIC_MEDIA_UPLOAD: {
    key: 'public-media-upload',
    slug: '/public/media/upload/:mediaFor',
  },
  USER: {
    key: 'user',
    slug: '/user',
    multiple: true,
  },
  ADMIN_LOGIN: {
    key: 'admin-login',
    slug: '/admin/login',
    CHILD: {
      SIGNUP: { slug: '/signup', key: 'signup' },
      LOGIN: { slug: '/login', key: 'login' },
    },
  },
  LOGOUT: {
    key: 'logout',
    slug: '/logout',
  },
  CHANGE_PASSWORD: {
    key: 'change-password',
    slug: '/change-password',
  },
  FORGOT_PASSWORD: {
    key: 'forgot-password',
    slug: '/forgot-password',
  },
  RESET_PASSWORD: {
    key: 'reset-password',
    slug: '/reset-password',
  },
  ACCOUNT_ME: {
    key: 'account-me',
    slug: '/account/me',
  },
  UPDATE_PROFILE: { slug: '/update-profile', key: 'update-profile' },
};

module.exports.getModule = () => moduleKey;
