const config = require('../config/index.js');
const emailer = require('./email.service.js');
const ejsTemplate = require('./ejs.service.js');
const { emailErrorMessage } = require('../logMessages/index.js');
const models = require('../v1/models/index.js');

const { EmailTemplate, User } = models;
const {
  app: { adminUrl, baseUrl },
} = config;

/**
 * Common message create
 * @param {Object} data
 */

/**
 * @param {Object} where - Criteria to filter user details.
 * @param {boolean} limitType - Flag indicating whether to limit the result to 1.
 * @returns {Promise<Array>} - A promise that resolves to an array of user details.
 * @throws {Error} - If an error occurs during the execution.
 */
const userDetail = async (where, limitType = false) => {
  try {
    const limit = limitType ? { limit: 1 } : {};
    return await User.scope('notDeletedUser').findAll({
      where,
      ...limit,
    });
  } catch (error) {
    throw Error(error);
  }
};
module.exports.emailSend = async (req, object) => {
  try {
    const { user, body } = req;
    const attachments = object?.attachments ?? null;
    const email = object?.email ?? body?.email ?? req?.user?.email;
    const where = {};
    const userId = object?.userId;
    const isDefaultConfigAdmin = object?.isDefaultConfigAdmin ?? false;
    const isWhereIgnore = object?.isWhereIgnore ?? false;
    let limitType = false;
    if (object?.emailTemplateId && !isWhereIgnore) {
      where.id = object?.emailTemplateId;
    } else if (
      ((Array.isArray(userId) && userId.length > 0) ||
        (userId && !Array.isArray(userId))) &&
      !isWhereIgnore
    ) {
      where.id = userId;
    } else if ((object?.contactEmail || email) && !isWhereIgnore) {
      where.email = object?.contactEmail ?? email ?? '';
    } else {
      limitType = true;
    }
    let userDetailsArray = await userDetail(where, limitType);
    if (object?.isGeneralUser) {
      userDetailsArray = [{ email }];
    }
    if (userDetailsArray && userDetailsArray.length > 0) {
      return await Promise.all(
        userDetailsArray.map(async (item) => {
          try {
            const emailTemplateUserId = object?.emailTemplateId ?? null;
            if (object?.emailType) {
              const emailTemplateResult = await this.emailTemplateGet(
                object?.emailType,
                emailTemplateUserId
              );
              let mailBody = object?.emailBody ?? emailTemplateResult?.body;
              const mailContent = emailTemplateResult?.body;
              const subject = emailTemplateResult?.subject;
              if (emailTemplateResult) {
                switch (object?.emailType) {
                  case 'USER_FORGOT_PASSWORD':
                    mailBody = mailBody
                      .replace(
                        '#NAME#',
                        `${user?.firstName ?? ''} ${user?.lastName ?? ''}`
                      )
                      .replace('#EMAIL#', user?.email)
                      .replace('#Password#', body?.newPassword);
                    break;
                  case 'USER_RESET_PASSWORD':
                    mailBody = mailBody
                      .replace(
                        '#LINK#',
                        `<a href="${adminUrl}reset-password/${object?.token}">Click</a>`
                      )
                      .replace(
                        '#NAME#',
                        `${user?.firstName ?? ''} ${user?.lastName ?? ''}`
                      );
                    break;
                  default:
                    break;
                }
                let emailObject = {
                  subject: subject ?? emailTemplateResult?.subject,
                  mailBody,
                  email,
                  isDefaultConfigAdmin,
                  isMarketingConfig: object?.isMarketingConfig ?? false,
                  emailTemplateUserId,
                  attachments,
                };
                emailObject = {
                  subject: subject ?? emailTemplateResult?.subject,
                  mailBody,
                  email,
                  isMarketingConfig: object?.isMarketingConfig ?? false,
                  emailTemplateUserId,
                  isDefaultConfigAdmin,
                  attachments,
                };
                if (Array.isArray(userId) && userId.length > 0) {
                  emailObject.mailBody = mailBody.replace(
                    '#NAME#' ?? '#Contact_Name#',
                    `${item?.firstName ?? ''} ${item?.lastName ?? ''}`
                  );
                  emailObject.email = item?.email ?? item?.email;
                }
                if (
                  Array.isArray(userId) &&
                  userId.some((items) => typeof items === 'object')
                ) {
                  userId.forEach((items) => {
                    emailObject.mailBody = mailContent
                      .replace(
                        '#NAME#',
                        `${items?.firstName ?? ''} ${items?.lastName ?? ''}`
                      )
                      .replace(
                        '#Contact_Name#',
                        `${items?.firstName ?? ''} ${items?.lastName ?? ''}`
                      )
                      .replace(
                        '#LINK#',
                        `${adminUrl}/admin/standard-operating-procedure`
                      );
                    emailObject.email = items?.email ?? null;
                    emailObject.shouldSame = object?.shouldSame;
                    if (emailObject) {
                      return this.ejsTemplateGenerate(emailObject);
                    }
                  });
                } else {
                  emailObject.shouldSame = object?.shouldSame;
                  return await this.ejsTemplateGenerate(emailObject);
                }
              }
            }
          } catch (error) {
            emailErrorMessage('templateDataReplace', { error, body: object });
          }
        })
      );
    }
    return false;
  } catch (error) {
    emailErrorMessage('templateDataReplace', { error, body: object });
    throw Error(error);
  }
};

/**
 * Get email template
 * @param {Object} data
 */
module.exports.emailTemplateGet = async (key, emailTemplateUserId) => {
  try {
    const where = { emailCode: key };
    if (emailTemplateUserId) {
      where.userId = emailTemplateUserId;
    }
    return await EmailTemplate.findOne({
      where,
    });
  } catch (error) {
    emailErrorMessage('templateGet', { error, body: key });
    throw Error(error);
  }
};

/**
 * Get email template generate
 * @param {Object} data
 */
module.exports.ejsTemplateGenerate = async (object) => {
  try {
    const { mailBody, subject, email } = object;
    const copyRightResult = null;
    const companyResult = null;
    const noReplyEmail = null;
    const templateLogo = `${baseUrl}public/logo.png`;
    const data = {
      mailBody,
      copyRightText: copyRightResult,
      companyName: companyResult,
      redirectUrl: adminUrl,
      logo: templateLogo,
      mailFooter: object?.isMailFooter ?? 'test',
    };
    const ejsResult = await ejsTemplate.generateEjsTemplate({
      template: 'common.ejs',
      data,
    });
    const options = {
      to: email,
      subject,
      noReplyEmail,
      isMarketingConfig: object?.isMarketingConfig ?? false,
      message: ejsResult,
    };
    if (object?.attachments) {
      options.attachments = object?.attachments;
    }
    return await emailer.verifyEmailServer(options);
  } catch (error) {
    emailErrorMessage('templateGenerate', { error, body: object });
    throw Error(error);
  }
};
