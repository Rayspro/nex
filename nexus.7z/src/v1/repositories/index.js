const accountRepository = require('./account.repository.js');
const userActivityRepository = require('./user-activity.repository.js');

module.exports = {
  accountRepository,
  userActivityRepository
};
