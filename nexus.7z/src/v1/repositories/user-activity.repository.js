const models = require('../models/index.js');

const { UserActivity } = models;

module.exports.createActivity = async (activityName, activityStatus, locationIp, userId) => {
  try {
    const payload = {
      ip: locationIp,
      activityType: activityName,
      activityStatus: activityStatus
    }

    if (userId) {
      payload.userId = userId;
    }
    const user = await UserActivity.create({ ...payload })
    return user;
  } catch (err) {
    throw Error(err);
  }
}

module.exports.getUserActivity = async (id, page = 1, pageSize = 10) => {
  try {
    const offset = (page - 1) * pageSize;
    const users = await models.UserActivity.findAndCountAll({
      where: { userId: id },
      include: [
        {
          model: models.User,
          attributes: ['id', 'firstName', 'lastName', 'email']
        }
      ],
      limit: pageSize,
      offset: offset,
      order: [['createdAt', 'desc']]
    });

    return users;
  } catch (err) {
    throw Error(err);
  }
}