const models = require('../models/index.js');
const { createHashPassword } = require('./account.repository.js');

const { User, UserIp } = models;

module.exports.createUser = async (firstName, lastName, email, imposedBy, password, allowedIp = "", restrictionType = "public") => {
  try {
    const hashedPaswword = await createHashPassword(password);
    const user = await User.create({ firstName, lastName, email, password: hashedPaswword });
    await UserIp.create({ userId: user.id, imposedBy: imposedBy, allowedIp, restrictionType });
    return user;
  } catch (err) {
    console.log(err);
    throw Error(error);
  }
}

module.exports.getUsers = async (page = 1, pageSize = 10) => {
  try {
    const offset = (page - 1) * pageSize;
    const users = await models.User.findAndCountAll({
      limit: pageSize,
      offset: offset,
      order: [['createdAt', 'desc']],
      include: [{
        model: UserIp,
        include: [{
          model: models.User,

        }]
      }]
    });
    return users;
  } catch (err) {
    throw Error(err);
  }
}