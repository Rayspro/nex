const accountController = require('./account.controller.js');
const userController = require('./user.controller.js');
const userActivityController = require('./user-activity.controller.js');

module.exports = {
  accountController,
  userActivityController
};
