module.exports = (sequelize, DataTypes) => {
  /**
   * Define the UserDevice model using Sequelize.
   * @param {object} sequelize - The Sequelize instance
   * @param {object} DataTypes - The data types provided by Sequelize
   * @returns {object} - The UserDevice model
   */
  const UserDevice = sequelize.define(
    'UserDevice',
    {
      userId: {
        type: DataTypes.INTEGER,
      },
      deviceId: {
        type: DataTypes.TEXT,
      },
      accessToken: {
        type: DataTypes.TEXT,
      },
      deviceType: {
        type: DataTypes.ENUM('web', 'ios', 'android'),
      },
    },
    {
      underscored: true,
    }
  );
  UserDevice.associate = (models) => {
    UserDevice.belongsTo(models.User, {
      foreignKey: 'userId',
    });
  };
  return UserDevice;
};
