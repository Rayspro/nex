const { Router } = require('express');
const controllers = require('../controllers/index.js');
const validations = require('../validations/index.js');
const middlewares = require('../middlewares/index.js');
const passport = require('passport');
const router = Router();
const { accountController } = controllers;
const { accountValidator } = validations;
const {
  validateMiddleware,
  accountMiddleware,
  authMiddleware,
} = middlewares;

router.get('/auth/google', passport.authenticate('google', { scope: ['profile', 'email'] }));

router.get('/auth/google/callback', passport.authenticate('google', { session: false }), accountController.socialLogin);

router.get('/auth/facebook', passport.authenticate('facebook'));

router.get('/auth/facebook/callback', passport.authenticate('facebook', { session: false }), (req, res) => {
  res.json({ token: req.user.token, user: req.user.user });
});

// Route for user signup
router.post(
  "/signup",
  validateMiddleware(accountValidator.userAccountSignupSchema),
  accountMiddleware.checkEmailExists,
  accountController.signup
);

// Route for user login
router.post(
  "/login",
  validateMiddleware(accountValidator.userAccountLoginSchema),
  accountController.checkUserAccountLogin
);
// Route for user logout
router.get(
  "/logout",
  authMiddleware,
  accountController.logout // Controller function for user logout
);

// Route for getting user details
router.get(
  "/my-account", // Route path
  authMiddleware,
  accountController.getUserDetail
);

module.exports = router; 
