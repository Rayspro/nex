const validateMiddleware = require('./validate.middleware.js');
const accountMiddleware = require('./account.middleware.js');
const authMiddleware = require('./auth.middleware.js');

module.exports = {
  validateMiddleware,
  accountMiddleware,
  authMiddleware
};
