const jwt = require('../../services/jwt.service.js');
const utility = require('../../utils/index.js');
const accountRepository = require('../repositories/account.repository.js');
const models = require('../models/index.js');

const { User } = models;

/**
 * Check user authorization
 * @param {Object} req - The request object containing headers for authorization
 * @param {Object} res - The response object
 * @param {Function} next - The next middleware function
 */
const authValidateRequest = async (req, res, next) => {
  try {
    if (req?.headers && req?.headers?.authorization) {
      const parts = req.headers.authorization.split(' ');
      const unauthorizedError = utility.httpStatus('UNAUTHORIZED');
      if (parts.length === 2) {
        const scheme = parts[0];
        const token = parts[1]; // This line remains unchanged
        if (/^Bearer$/i.test(scheme)) {
          const decodedToken = jwt.verifyToken(token);
          if (decodedToken.id) {
            const user = await User.findOne({
              where: {
                id: decodedToken.id,
              },
            });
            if (user) {
              const userToken = await accountRepository.getDeviceDetailByToken(token);
              if (userToken) {
                req.user = user;
                req.userToken = userToken;
                next();
              } else {
                const error = new Error('TOKEN_BAD_FORMAT');
                error.status = unauthorizedError;
                error.message = utility.getMessage(
                  req,
                  false,
                  'SESSION_EXPIRE'
                );
                next(error);
              }
            } else {
              const error = new Error('TOKEN_NOT_FOUND');
              error.status = utility.httpStatus('UNAUTHORIZED');
              error.message = utility.getMessage(
                req,
                false,
                'UNAUTHORIZED_USER_ACCESS'
              );
              next(error);
            }
          } else {
            const error = new Error('TOKEN_BAD_FORMAT');
            error.status = unauthorizedError;
            error.message = utility.getMessage(req, false, 'SESSION_EXPIRE');
            next(error);
          }
        } else {
          const error = new Error('TOKEN_BAD_FORMAT');
          error.status = unauthorizedError;
          error.message = utility.getMessage(
            req,
            false,
            'UNAUTHORIZED_USER_ACCESS'
          );
          next(error);
        }
      } else {
        const error = new Error('TOKEN_NOT_FOUND');
        error.status = utility.httpStatus('UNAUTHORIZED');
        error.message = utility.getMessage(
          req,
          false,
          'UNAUTHORIZED_USER_ACCESS'
        );
        next(error);
      }
    } else {
      const error = new Error('TOKEN_NOT_FOUND');
      error.status = utility.httpStatus('UNAUTHORIZED');
      error.message = utility.getMessage(
        req,
        false,
        'UNAUTHORIZED_USER_ACCESS'
      );
      next(error);
    }
  } catch (e) {
    const error = new Error('TOKEN_NOT_FOUND');
    error.status = utility.httpStatus('UNAUTHORIZED');
    error.message = utility.getMessage(req, false, 'SESSION_EXPIRE');
    next(error);
  }
};

module.exports = authValidateRequest;
