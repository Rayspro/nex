module.exports = {
  TO_MANY_REQUEST: 'Too many requests, please try again later.',
  PHONE_NUMBER_FORMAT: 'Should contain only numeric value 4-15 digits.',
  PHONE_NOT_FOUND: 'Mobile number not exist.',
  TOKEN_EXPIRED: 'Reset link expired.',
  EMAIL_NOT_FOUND_OLD:
    'Sorry, there is no account associated with entered details. Please try with email.',
  FORGOT_EMAIL_NOT_FOUND:
    'Sorry! The Email address you have entered is not found.',
  FORGOT_MOBILE_NUMBER_NOT_FOUND:
    'Sorry, there is no account associated with entered details. Please try with Mobile Number.',
  EMAIL_NOT_FOUND: 'Sorry! The Email address you have entered is not found.',
  CURRENT_PASSWORD_MATCH: 'Current password is incorrect.',
  PASSWORD_NOT_MATCH: 'Passwords do not match',
  CURRENT_PASSWORD_NOT_MATCH:
    'New password should be different from your old password.',
  PASSWORD_REGEX:
    'Password should contain at least one number and one special character',
  WRONG_CREDENTIAL: 'Email or Password is Wrong',
  LOGIN_SUCCESS: 'Login successful.',
  PERMISSION_NOT_ALLOW: "NCA users don't have login permission",
  LOGOUT_SUCCESS: 'Logout successful.',
  PASSWORD_CHANGED: 'Password has been changed successfully.',
  PASSWORD_NOT_CHANGED: 'Password not changed!',
  INVALID_PASSWORD: 'Old password is wrong.',
  UNAUTHORIZED_ACCESS: 'Unauthorized user access',
  SIGNUP: 'Your account has been created. Please login',
  SEND_EMAIL_VERIFICATION: 'A verification code has been sent to your email.',
  MOBILE_ALREADY_EXIST: 'Mobile number already exists.',
  INVALID_OTP: 'Verification code is wrong.',
  PHONE_EXIST: 'This number is already in use. Please enter another number.',
  EMAIL_EXIST: 'Email already exists.',
  DELETED_EMAIL_EXIST:
    'Account associated with this email is deleted. please contact admin',
  DELETED_MOBILE_ALREADY_EXIST:
    'Account associated with this mobile number is deleted. please contact admin',
  USER_NOT_FOUND: 'User not found.',
  USER_DELETED_NOT_FOUND:
    'Your account seems to be deleted. Please contact support for further assistance.',
  USER_DETAIL: 'User detail.',
  INVALID_ACCESS: 'Invalid user access.',
  PASSWORD_LINK_SENT: 'Reset password link has been sent on your email.',
  PASSWORD_LINK_NOT_SENT: 'Reset link not send!',
  PASSWORD_LINK_EXPIRED:
    'It seems this link is expired or you have already changed your password.',
  CHANGE_MOBILE_OTP_SENT: 'A OTP has been sent to your mobile via SMS.',
  CHANGE_MOBILE_OTP_VERIFY: 'Mobile number verified successfully.',
  PASSWORD_MISMATCH: 'Password and confirm password not match.',
  PASSWORD_CREATED_SUCCESS: 'Password reset successfully.',
  LINK_EXPIRE: 'This reset password link has expired.',
  INTERNAL_ERROR: 'Internal Server Error',
  CUSTOMER_PASSWORD: 'test@123',
  FILE_UPLOADED: 'File uploaded successfully',
  MODULE_NOT_FOUND: 'Module not found',
  PHONE_NUMBER_MAX_LENGTH: 'Phone number length must be 10 digits only',
  ACCOUNT_DELETED: 'User account deleted successfully',
  MOBILE_NUMBER_ALREADY_EXISTS: 'Mobile number already exist',
  PROFILE_UPDATED: 'Profile updated successfully.',
  EMAIL_MOBILE_NUMBER_ALLOWED:
    'Please enter Email and mobile number proper format',

  /**
   * Auth message
   */
  SESSION_EXPIRE: 'Your session is expired. Please login again.',
  ACCOUNT_INACTIVE:
    'You are not active, Please contact support for further assistance',
  CUSTOMER_ZERO_AMOUNT_ALERT:
    'Booking amount must be greater than 0. Please contact SP/ Admin to make the payment.',
  ACCOUNT_DELETE:
    'Your account seems to be deleted. Please contact support for further assistance.',
  UNAUTHORIZED_USER_ACCESS: 'Unauthorized access or token required.',
  /**

  /*
   * Media uploader message
   */
  TOO_LARGE_FILE: 'File too Big, please select a file less than 15MB.',
  MEDIA_INVALID: 'Media is not valid',

  /**
   * Email subject
   */
  FORGET_PASSWORD_SUBJECT: 'password.',
  USER_STATUS_UPDATED: 'User Status Updated Successfully',
  USER_DELETED: 'User successfully deleted.',
  USER_SERVICE_NOT_EXISTS: 'User services not exists',
  USER_UPDATED: 'User successfully updated.',
};
