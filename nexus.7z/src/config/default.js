const utils = require('../utils/environment.js');

const defaultCountryCode = utils.getEnv('DEFAULT_COUNTRY') ?? 'US';
const emailSend = ['backend@mailinator.com'];
const defaultAdminRoleEmail = 'admin@mailinator.com';

// Function to retrieve the default country code
module.exports.defaultCountryCode = () => {
  try {
    return defaultCountryCode;
  } catch (error) {
    return error;
  }
};

// Function to retrieve the default admin email
module.exports.defaultAdminEmail = () => {
  try {
    return defaultAdminRoleEmail;
  } catch (error) {
    return error;
  }
};

// Function to retrieve the email addresses for sending errors
module.exports.errorEmailGet = () => {
  try {
    return emailSend;
  } catch (error) {
    return error;
  }
};
