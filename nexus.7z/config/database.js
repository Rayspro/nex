/* eslint-disable */
const { port } = require("../src/config/database");
module.exports = {
  // Development environment configuration
  development: {
    host: process.env.DB_HOST,
    username: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    port: process.env.DB_PORT || port,
    dialect: process.env.DB_DRIVER, // Database dialect
  },
  // Test environment configuration
  test: {
    username: process.env.CI_DB_USERNAME, 
    password: process.env.CI_DB_PASSWORD, 
    database: process.env.CI_DB_NAME, 
    port: process.env.CI_DB_PORT || port, 
    host: process.env.DB_HOST,
    dialect: process.env.DB_DRIVER, 
  },
  // Staging environment configuration
  staging: {
    host: process.env.DB_HOST,
    username: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    port: process.env.DB_PORT || port,
    dialect: process.env.DB_DRIVER, 
  },
  // Production environment configuration
  production: {
    host: process.env.DB_HOST,
    username: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    port: process.env.DB_PORT || port,
    dialect: process.env.DB_DRIVER, 
  },
};
