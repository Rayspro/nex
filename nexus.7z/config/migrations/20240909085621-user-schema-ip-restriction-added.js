'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  up: (queryInterface, Sequelize) =>
    queryInterface.sequelize.transaction((t) =>
      Promise.all([
        queryInterface.describeTable('users').then((tableDefinition) => {
          if (!tableDefinition['restrction_type']) {
            return queryInterface.addColumn(
              'users',
              'restrction_type',
              {
                type: Sequelize.STRING(255),
                allowNull: true,
              },
              { transaction: t }
            );
          }
        }),
        queryInterface.describeTable('users').then((tableDefinition) => {
          if (!tableDefinition['allowed_ip']) {
            return queryInterface.addColumn(
              'users',
              'allowed_ip',
              {
                type: Sequelize.STRING(255),
                allowNull: true,
              },
              { transaction: t }
            );
          }
        })
      ])
    ),
  down: (queryInterface) =>
    queryInterface.sequelize.transaction((t) =>
      Promise.all([
        queryInterface.removeColumn('users', 'restrction_type', {
          transaction: t,
        }),
        queryInterface.removeColumn('users', 'allowed_ip', {
          transaction: t,
        }),
      ])
    ),
};
