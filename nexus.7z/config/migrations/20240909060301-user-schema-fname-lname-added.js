'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  up: (queryInterface, Sequelize) =>
    queryInterface.sequelize.transaction((t) =>
      Promise.all([
        queryInterface.describeTable('users').then((tableDefinition) => {
          if (!tableDefinition['first_name']) {
            return queryInterface.addColumn(
              'users',
              'first_name',
              {
                type: Sequelize.STRING(255),
                allowNull: true,
              },
              { transaction: t }
            );
          }
        }),
        queryInterface.describeTable('users').then((tableDefinition) => {
          if (!tableDefinition['last_name']) {
            return queryInterface.addColumn(
              'users',
              'last_name',
              {
                type: Sequelize.STRING(255),
                allowNull: true,
              },
              { transaction: t }
            );
          }
        }),
        queryInterface.describeTable('users').then((tableDefinition) => {
          if (tableDefinition['name']) {
            return queryInterface.removeColumn("users", "name", { transaction: t });
          }
        }),
      ])
    ),
  down: (queryInterface) =>
    queryInterface.sequelize.transaction((t) =>
      Promise.all([
        queryInterface.removeColumn('users', 'first_name', {
          transaction: t,
        }),
        queryInterface.removeColumn('users', 'last_name', {
          transaction: t,
        }),
      ])
    ),
};
